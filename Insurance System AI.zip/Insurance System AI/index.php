<?php
session_start();
$conn = new mysqli("localhost", "root", "", "insurance_ai");
if ($conn->connect_error) die("DB Connection Failed: " . $conn->connect_error);

// Registration handler
if (isset($_POST['register'])) {
    $name = $_POST['reg_name'];
    $email = $_POST['reg_email'];
    $phone = $_POST['reg_phone'];
    $password = password_hash($_POST['reg_password'], PASSWORD_DEFAULT); // Using secure password hashing
    
    $check = $conn->prepare("SELECT * FROM users WHERE email=?");
    $check->bind_param("s", $email);
    $check->execute();
    $result = $check->get_result();
    
    if ($result->num_rows > 0) {
        $message = "Email already registered!";
        $message_type = "error";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (username, email, phone, password) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $phone, $password);
        $stmt->execute();
        $message = "Registration successful! Please log in.";
        $message_type = "success";
    }
}

// Login handler
if (isset($_POST['login'])) {
    $email = $_POST['login_email'];
    $password = $_POST['login_password'];
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['email'] = $email;
            $_SESSION['name'] = $user['name'];
            header("Location: dashboard.php");
            exit;
        } else {
            $message = "Invalid password.";
            $message_type = "error";
        }
    } else {
        $message = "Email not found.";
        $message_type = "error";
    }
}

// Password recovery - Step 1: Verify phone
if (isset($_POST['verify_phone'])) {
    $recover_email = $_POST['recover_email'];
    $recover_phone = $_POST['recover_phone'];
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE email=? AND phone=?");
    $stmt->bind_param("ss", $recover_email, $recover_phone);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Phone verified, set session to allow password reset
        $_SESSION['reset_email'] = $recover_email;
        $message = "Phone verified successfully. Please set your new password.";
        $message_type = "success";
        $show_reset_form = true;
    } else {
        $message = "Password recovery failed. Email or phone number not found.";
        $message_type = "error";
    }
}

// Password recovery - Step 2: Reset password
if (isset($_POST['reset_password'])) {
    if (isset($_SESSION['reset_email'])) {
        $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("UPDATE users SET password=? WHERE email=?");
        $stmt->bind_param("ss", $new_password, $_SESSION['reset_email']);
        $stmt->execute();
        
        $message = "Password has been reset successfully. Please login with your new password.";
        $message_type = "success";
        unset($_SESSION['reset_email']);
    } else {
        $message = "Invalid password reset request.";
        $message_type = "error";
    }
}

// Logout handler
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Insurance AI Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="icon" href="Images/logo.png" type="image/png">
    <link rel="stylesheet" href="Css/login.css">
</head>
<body>
<div class="container">
    <!-- Logo and Branding Section -->
    <div class="logo-section">
        <div class="logo">
            <img src="Images/Logo.png" alt="Insurance AI Logo">
        </div>
        <h1>Insurance AI Portal</h1>
        <p>Your smart insurance solution for the digital age</p>
    </div>

    <!-- Form Section -->
    <div class="form-section">
        <?php if (isset($_SESSION['email'])): ?>
            <h2>Welcome, <?= htmlspecialchars($_SESSION['name']) ?>!</h2>
            <p style="text-align: center; margin-bottom: 20px;">You are logged in as <strong><?= htmlspecialchars($_SESSION['email']) ?></strong></p>
            <form method="GET">
                <button name="logout"><i class="fas fa-sign-out-alt"></i> Logout</button>
            </form>
        <?php else: ?>
            <div class="tabs">
                <button class="tab-btn active" onclick="showTab('login')" id="tab-login">Login</button>
                <button class="tab-btn" onclick="showTab('register')" id="tab-register">Register</button>
                <button class="tab-btn" onclick="showTab('recover')" id="tab-recover">Recover Password</button>
            </div>

            <?php if (isset($message)): ?>
                <div class="message <?= $message_type ?>">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <!-- Login Form -->
            <form method="POST" id="form-login">
                <div class="form-group">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="login_email" placeholder="Email Address" required>
                </div>
                <div class="form-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="login_password" placeholder="Password" required>
                </div>
                <button type="submit" name="login"><i class="fas fa-sign-in-alt"></i> Login</button>
            </form>

            <!-- Registration Form -->
            <form method="POST" id="form-register" style="display:none;">
                <div class="form-group">
                    <i class="fas fa-user"></i>
                    <input type="text" name="reg_name" placeholder="Full Name" required>
                </div>
                <div class="form-group">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="reg_email" placeholder="Email Address" required>
                </div>
                <div class="form-group">
                    <i class="fas fa-phone"></i>
                    <input type="tel" name="reg_phone" placeholder="Phone Number" required>
                </div>
                <div class="form-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="reg_password" placeholder="Password" required minlength="8">
                </div>
                <div class="form-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="reg_confirm_password" placeholder="Confirm Password" required minlength="8">
                </div>
                <button type="submit" name="register"><i class="fas fa-user-plus"></i> Register</button>
            </form>

            <!-- Recovery Form - Phone Verification -->
            <form method="POST" id="form-recover" style="display:none;">
                <?php if (!isset($show_reset_form)): ?>
                <div class="form-group">
                    <i class="fas fa-envelope"></i>
                    <input type="email" name="recover_email" placeholder="Your Email Address" required>
                </div>
                <div class="form-group">
                    <i class="fas fa-phone"></i>
                    <input type="tel" name="recover_phone" placeholder="Your Phone Number" required>
                </div>
                <button type="submit" name="verify_phone"><i class="fas fa-check"></i> Verify Phone</button>
                <?php else: ?>
                <!-- Password Reset Form -->
                <div class="form-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="new_password" placeholder="New Password" required minlength="8">
                </div>
                <div class="form-group">
                    <i class="fas fa-lock"></i>
                    <input type="password" name="confirm_new_password" placeholder="Confirm New Password" required minlength="8">
                </div>
                <button type="submit" name="reset_password"><i class="fas fa-key"></i> Reset Password</button>
                <?php endif; ?>
            </form>
        <?php endif; ?>
    </div>
</div>

<script>
function showTab(tab) {
    // Remove active class from all tabs
    document.querySelectorAll('.tab-btn').forEach(function(btn) {
        btn.classList.remove('active');
    });
    
    // Add active class to selected tab
    document.getElementById('tab-' + tab).classList.add('active');
    
    // Hide all forms
    document.querySelectorAll('form[id^="form-"]').forEach(function(form) {
        form.style.display = 'none';
    });
    
    // Show selected form
    document.getElementById('form-' + tab).style.display = 'block';
}

// Form validation
document.getElementById('form-register').addEventListener('submit', function(e) {
    const password = document.querySelector('input[name="reg_password"]').value;
    const confirmPassword = document.querySelector('input[name="reg_confirm_password"]').value;
    
    if (password !== confirmPassword) {
        e.preventDefault();
        alert('Passwords do not match');
    }
});

document.getElementById('form-recover').addEventListener('submit', function(e) {
    if (document.querySelector('input[name="new_password"]')) {
        const password = document.querySelector('input[name="new_password"]').value;
        const confirmPassword = document.querySelector('input[name="confirm_new_password"]').value;
        
        if (password !== confirmPassword) {
            e.preventDefault();
            alert('Passwords do not match');
        }
    }
});
</script>
</body>
</html>