<?php
// Database
$host = 'localhost'; $dbname = 'insurance_ai'; $username = 'root'; $password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

// Get statistics
$totalPaymentsQuery = $pdo->query("SELECT SUM(amount) as total_payments FROM payments");
$totalPayments = $totalPaymentsQuery->fetch(PDO::FETCH_ASSOC)['total_payments'] ?? 0;

$totalClientsQuery = $pdo->query("SELECT COUNT(*) as total_clients FROM clients");
$totalClients = $totalClientsQuery->fetch(PDO::FETCH_ASSOC)['total_clients'] ?? 0;

$totalClaimsQuery = $pdo->query("SELECT SUM(claim_amount) as total_claims FROM claims");
$totalClaims = $totalClaimsQuery->fetch(PDO::FETCH_ASSOC)['total_claims'] ?? 0;

$previousSales = 100000; 
$salesGrowth = $previousSales > 0 ? (($totalPayments - $previousSales) / $previousSales) * 100 : 0;

// Start session and get user from database
session_start(); 

// Check if user is logged in
if (!isset($_SESSION['email'])) {
    header('Location: index.php');
    exit;
}

// Get user data from database
$email = $_SESSION['email'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
$stmt->execute([$email]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    session_destroy();
    header('Location: index.php?error=user_not_found');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance AI Portal | Dashboard</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="Css/dash.css">
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-container">
                <img src="Images/Logo.png" alt="Insurance AI Logo" class="logo">
                <span class="company-name">Insurance AI</span>
            </div>
        </div>
        
        <nav class="navigation">
            <a href="dashboard.php" class="nav-item active">
                <i class="fas fa-tachometer-alt nav-icon"></i>
                Dashboard
            </a>
            <a href="Pages/clients.php" class="nav-item">
                <i class="fas fa-users nav-icon"></i>
                Clients
            </a>
            <a href="Pages/payments.php" class="nav-item">
                <i class="fas fa-money-check-dollar nav-icon"></i>
                Payments
            </a>
            <a href="Pages/policies.php" class="nav-item">
                <i class="fas fa-book nav-icon"></i>
                Policies
            </a>
            <a href="Pages/analysis.php" class="nav-item">
                <i class="fas fa-chart-bar nav-icon"></i>
                Analysis
            </a>
            <a href="Pages/Data Search.php" class="nav-item">
                <i class="fas fa-search nav-icon"></i>
                Data Search
            </a>
            <a href="Pages/Claims.php" class="nav-item">
                <i class="fas fa-file-invoice-dollar nav-icon"></i>
                Claims
            </a>
            <a href="Pages/Report.php" class="nav-item">
                <i class="fas fa-file-alt nav-icon"></i>
                Reports
            </a>
            <a href="index.php?logout=true" class="nav-item">
                <i class="fas fa-sign-out-alt nav-icon"></i>
                Logout
            </a>
        </nav>
        
        <div class="sidebar-footer">
            &copy; <?= date('Y') ?> Insurance AI Portal
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="top-bar">
            <h1 class="page-title">Dashboard</h1>
            
            <div class="user-profile">
                <img src="Images/avatar.png" alt="User Avatar" class="avatar">
                <div class="user-info">
                    <span class="user-name"><?= htmlspecialchars($user['username']) ?></span>
                    <span class="user-email"><?= htmlspecialchars($user['email']) ?></span>
                </div>
            </div>
        </div>
        
        <div class="dashboard-container">
            <!-- Stats Cards -->
            <div class="stats-cards">
                <div class="stat-card">
                    <h2 class="stat-title">Total Payments</h2>
                    <p class="stat-value">MKW <?= number_format($totalPayments, 2) ?></p>
                </div>
                
                <div class="stat-card">
                    <h2 class="stat-title">Total Clients</h2>
                    <p class="stat-value"><?= number_format($totalClients) ?></p>
                </div>
                
                <div class="stat-card">
                    <h2 class="stat-title">Total Claims</h2>
                    <p class="stat-value">MKW <?= number_format($totalClaims, 2) ?></p>
                </div>
            </div>
            
            <!-- Growth Card -->
            <div class="growth-card">
                <h2 class="growth-title">Sales Growth</h2>
                <p class="stat-value <?= $salesGrowth >= 0 ? 'positive-growth' : 'negative-growth' ?>">
                    <?= $salesGrowth >= 0 ? '+' : '' ?><?= number_format($salesGrowth, 2) ?>%
                </p>
            </div>
            
            <!-- Chart -->
            <div class="chart-container">
                <h2 class="chart-title">Summary Statistics</h2>
                <canvas id="summaryChart"></canvas>
            </div>
        </div>
    </main>

    <script>
        // Initialize chart
        const ctx = document.getElementById('summaryChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Total Payments', 'Total Clients', 'Total Claims'],
                datasets: [{
                    label: 'Summary',
                    data: [<?= $totalPayments ?>, <?= $totalClients ?>, <?= $totalClaims ?>],
                    backgroundColor: [
                        'rgba(59, 130, 246, 0.7)', // Blue
                        'rgba(6, 182, 212, 0.7)',  // Cyan
                        'rgba(30, 58, 138, 0.7)'   // Dark Blue
                    ],
                    borderColor: [
                        'rgba(59, 130, 246, 1)',
                        'rgba(6, 182, 212, 1)',
                        'rgba(30, 58, 138, 1)'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>
