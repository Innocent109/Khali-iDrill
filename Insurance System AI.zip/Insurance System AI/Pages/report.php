<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "insurance_ai";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all clients
$clients = [];
$sqlClients = "SELECT id, CONCAT(firstName, ' ', lastName) AS name FROM clients";
$resultClients = $conn->query($sqlClients);
if ($resultClients && $resultClients->num_rows > 0) {
    while ($row = $resultClients->fetch_assoc()) {
        $clients[] = $row;
    }
}

// Fetch all support specialists from users table
$specialists = [];
$sqlSpecialists = "SELECT id, CONCAT(username) AS name, email, phone FROM users";
$resultSpecialists = $conn->query($sqlSpecialists);
if ($resultSpecialists && $resultSpecialists->num_rows > 0) {
    while ($row = $resultSpecialists->fetch_assoc()) {
        $specialists[] = $row;
    }
}

// Fetch client data with policies and claims
$clientData = [];
$selectedSpecialist = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['client_id'])) {
    $clientId = (int) $_POST['client_id'];
    $specialistId = isset($_POST['specialist_id']) ? (int) $_POST['specialist_id'] : null;

    // Get selected specialist info
    if ($specialistId) {
        foreach ($specialists as $specialist) {
            if ($specialist['id'] == $specialistId) {
                $selectedSpecialist = $specialist;
                break;
            }
        }
    }

    $sql = "
        SELECT 
            c.id AS client_id, 
            CONCAT(c.firstName, ' ', c.lastName) AS client_name, 
            c.email, 
            c.phone,
            policies.id AS policy_id, 
            policies.policy_type, 
            policies.coverage_amount, 
            policies.policy_number, 
            claims.id AS claim_id, 
            claims.description, 
            claims.claim_amount, 
            claims.incident_date
        FROM 
            clients c
        LEFT JOIN 
            policies ON c.id = policies.client_Name
        LEFT JOIN 
            claims ON c.id = claims.client_id
        WHERE 
            c.id = ?;
    ";

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("i", $clientId);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $clientData[] = $row;
            }
        }
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance AI | Claims Performance Report</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../Css/report.css">
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-container">
                <img src="../Images/Logo.png" alt="Insurance AI Logo" class="logo">
                <span class="company-name">Insurance AI</span>
            </div>
        </div>
        
        <nav class="navigation">
            <a href="../dashboard.php" class="nav-item">
                <i class="fas fa-tachometer-alt nav-icon"></i>
                <span class="nav-text">Dashboard</span>
            </a>
            <a href="clients.php" class="nav-item">
                <i class="fas fa-users nav-icon"></i>
                <span class="nav-text">Clients</span>
            </a>
            <a href="payments.php" class="nav-item">
                <i class="fas fa-money-check-dollar nav-icon"></i>
                <span class="nav-text">Payments</span>
            </a>
            <a href="policies.php" class="nav-item">
                <i class="fas fa-book nav-icon"></i>
                <span class="nav-text">Policies</span>
            </a>
            <a href="analysis.php" class="nav-item">
                <i class="fas fa-chart-bar nav-icon"></i>
                <span class="nav-text">Analysis</span>
            </a>
            <a href="Data Search.php" class="nav-item">
                <i class="fas fa-search nav-icon"></i>
                <span class="nav-text">Data Search</span>
            </a>
            <a href="Claims.php" class="nav-item">
                <i class="fas fa-file-invoice-dollar nav-icon"></i>
                <span class="nav-text">Claims</span>
            </a>
            <a href="Report.php" class="nav-item active">
                <i class="fas fa-file-alt nav-icon"></i>
                <span class="nav-text">Reports</span>
            </a>
            <a href="../index.php?logout=true" class="nav-item">
                <i class="fas fa-sign-out-alt nav-icon"></i>
                <span class="nav-text">Logout</span>
            </a>
        </nav>
        
        <div class="sidebar-footer">
            &copy; <?= date('Y') ?> Insurance AI Portal
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="page-header">
            <div class="page-title">
                <div class="icon">
                    <i class="fas fa-file-alt"></i>
                </div>
                <h1>Report Performance</h1>
            </div>
            <div class="no-print">
                <button onclick="window.print()" class="btn btn-primary">
                    <i class="fas fa-print"></i> Print Report
                </button>
            </div>
        </div>
        
        <!-- Report Generation Form -->
        <div class="client-card no-print">
            <div class="card-header">
                <h2>Generate Report</h2>
            </div>
            
            <form method="POST">
                <div class="form-row">
                    <div class="form-col">
                        <div class="form-group">
                            <label for="client_id" class="form-label">Select Client</label>
                            <select name="client_id" id="client_id" required class="form-select">
                                <option value="" disabled selected>Select a client</option>
                                <?php foreach ($clients as $client): ?>
                                    <option value="<?php echo htmlspecialchars($client['id']); ?>" <?php echo (isset($_POST['client_id']) && $_POST['client_id'] == $client['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($client['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-col">
                        <div class="form-group">
                            <label for="specialist_id" class="form-label">Claims Support Specialist</label>
                            <select name="specialist_id" id="specialist_id" required class="form-select">
                                <option value="" disabled selected>Select a specialist</option>
                                <?php foreach ($specialists as $specialist): ?>
                                    <option value="<?php echo htmlspecialchars($specialist['id']); ?>" <?php echo (isset($_POST['specialist_id']) && $_POST['specialist_id'] == $specialist['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($specialist['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="btn-group">
                    <button type="reset" class="btn btn-secondary">Clear</button>
                    <button type="submit" class="btn btn-primary">Generate Report</button>
                </div>
            </form>
        </div>
        
        <?php if (!empty($clientData)): ?>
        <!-- Claims Performance Report -->
        <div class="client-card">
            <div class="card-header">
                <h2>Claims Performance Report</h2>
            </div>
            
            <div class="report-content">
                <div class="report-section">
                    <p>Dear Valued Client,</p>
                    <p style="margin-top: 10px;">We are pleased to provide you with a comprehensive overview of your insurance claims. 
                       This detailed report highlights your claims history, processing performance, and key insights.
                       Our team has carefully reviewed the details of your claim and we would like to share the following findings:</p>
                </div>
                
                <div class="report-section">
                    <h3>Customer Details</h3>
                    <table class="report-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?php echo htmlspecialchars($clientData[0]['client_name']); ?></td>
                                <td><?php echo htmlspecialchars($clientData[0]['email']); ?></td>
                                <td><?php echo htmlspecialchars($clientData[0]['phone']); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="report-section">
                    <h3>Policies</h3>
                    <table class="report-table">
                        <thead>
                            <tr>
                                <th>Policy ID</th>
                                <th>Policy Type</th>
                                <th>Coverage Amount</th>
                                <th>Policy Number</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $shown_policies = [];
                            foreach ($clientData as $data): 
                                if ($data['policy_id'] && !in_array($data['policy_id'], $shown_policies)):
                                    $shown_policies[] = $data['policy_id'];
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($data['policy_id']); ?></td>
                                <td><?php echo htmlspecialchars($data['policy_type']); ?></td>
                                <td><?php echo htmlspecialchars($data['coverage_amount']); ?></td>
                                <td><?php echo htmlspecialchars($data['policy_number']); ?></td>
                            </tr>
                            <?php 
                                endif;
                            endforeach; 
                            ?>
                            <?php if (empty($shown_policies)): ?>
                            <tr>
                                <td colspan="4" style="text-align: center;">No policies found.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="report-section">
                    <h3>Claims and Payments</h3>
                    <table class="report-table">
                        <thead>
                            <tr>
                                <th>Claim ID</th>
                                <th>Description</th>
                                <th>Amount Claimed</th>
                                <th>Claim Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $shown_claims = [];
                            foreach ($clientData as $data): 
                                if ($data['claim_id'] && !in_array($data['claim_id'], $shown_claims)):
                                    $shown_claims[] = $data['claim_id'];
                            ?>
                            <tr>
                                <td><?php echo htmlspecialchars($data['claim_id']); ?></td>
                                <td><?php echo htmlspecialchars($data['description']); ?></td>
                                <td><?php echo htmlspecialchars($data['claim_amount']); ?></td>
                                <td><?php echo htmlspecialchars($data['incident_date']); ?></td>
                            </tr>
                            <?php 
                                endif;
                            endforeach; 
                            ?>
                            <?php if (empty($shown_claims)): ?>
                            <tr>
                                <td colspan="6" style="text-align: center;">No claims found.</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="report-section">
                    <h3>Recommendations</h3>
                    <div class="recommendations">
                        <ul>
                            <li>Review policy coverage for potential gaps</li>
                            <li>Maintain comprehensive documentation for future claims</li>
                            <li>Consider additional property protection measures</li>
                            <li>Update emergency contact and medical information</li>
                        </ul>
                    </div>
                </div>
                
                <div class="report-section">
                    <p>We appreciate your patience as we work to resolve this matter. If you have any questions or need further assistance, 
                       please do not hesitate to contact us.</p>
                    <p style="margin-top: 10px;">Thank you for choosing our services.</p>
                </div>
                
                <div class="report-section">
                    <h3>Contact Information</h3>
                    <div class="contact-info">
                        <?php if ($selectedSpecialist): ?>
                        <p><strong>Claims Support Specialist:</strong></p>
                        <p><?php echo htmlspecialchars($selectedSpecialist['name']); ?></p>
                        <p>Email: <?php echo htmlspecialchars($selectedSpecialist['email']); ?></p>
                        <p>Direct Line: <?php echo htmlspecialchars($selectedSpecialist['phone']); ?></p>
                        <?php else: ?>
                        <p><strong>Claims Support Specialist:</strong></p>
                        <p>Not assigned</p>
                        <?php endif; ?>
                        <p style="margin-top: 10px;"><strong>24/7 Claims Hotline:</strong> +265 881 643 261</p>
                    </div>
                </div>
                
                <div class="report-footer">
                    <p>Report Generated: <?php echo date("F j, Y"); ?></p>
                    <p>&copy; <?= date('Y') ?> Insurance AI</p>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </main>
</body>
</html>