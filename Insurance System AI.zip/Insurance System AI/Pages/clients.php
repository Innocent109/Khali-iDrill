<?php
// Database connection
$dbHost = 'localhost';
$dbUser = 'root';
$dbPass = '';
$dbName = 'insurance_ai';

$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = isset($_POST['id']) ? intval($_POST['id']) : null;
    $firstName = trim($_POST['firstName']);
    $lastName = trim($_POST['lastName']);
    $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
    $phone = trim($_POST['phone']);
    $policyType = trim($_POST['policyType']);
    $address = trim($_POST['address']);
    $city = trim($_POST['city']);
    $paymentMode = trim($_POST['paymentMode']);

    if (!$email) {
        die("Invalid email address provided.");
    }

    if ($id) {
        // Update
        $stmt = $conn->prepare("UPDATE clients SET firstName = ?, lastName = ?, email = ?, phone = ?, policyType = ?, address = ?, city = ?, paymentMode = ? WHERE id = ?");
        $stmt->bind_param("ssssssssi", $firstName, $lastName, $email, $phone, $policyType, $address, $city, $paymentMode, $id);
    } else {
        // Add new 
        $stmt = $conn->prepare("INSERT INTO clients (firstName, lastName, email, phone, policyType, address, city, paymentMode) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssss", $firstName, $lastName, $email, $phone, $policyType, $address, $city, $paymentMode);
    }

    if ($stmt->execute()) {
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Delete client
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    if ($id > 0) {
        $stmt = $conn->prepare("DELETE FROM clients WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            header("Location: " . $_SERVER['PHP_SELF']);
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Invalid client ID.";
    }
}

$result = $conn->query("SELECT * FROM clients");
if ($result) {
    $clients = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $clients = [];
    echo "Error fetching clients: " . $conn->error;
}

// Start session to check login status
session_start();
if (!isset($_SESSION['email'])) {
    header('Location: ../index.php');
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance AI | Clients</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../Css/clients.css">
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-container">
                <img src="../Images/Logo.png" alt="Insurance AI Logo" class="logo">
                <span class="company-name">Insurance AI</span>
            </div>
        </div>
        
        <nav class="navigation">
            <a href="../dashboard.php" class="nav-item">
                <i class="fas fa-tachometer-alt nav-icon"></i>
                <span class="nav-text">Dashboard</span>
            </a>
            <a href="clients.php" class="nav-item active">
                <i class="fas fa-users nav-icon"></i>
                <span class="nav-text">Clients</span>
            </a>
            <a href="payments.php" class="nav-item">
                <i class="fas fa-money-check-dollar nav-icon"></i>
                <span class="nav-text">Payments</span>
            </a>
            <a href="policies.php" class="nav-item">
                <i class="fas fa-book nav-icon"></i>
                <span class="nav-text">Policies</span>
            </a>
            <a href="analysis.php" class="nav-item">
                <i class="fas fa-chart-bar nav-icon"></i>
                <span class="nav-text">Analysis</span>
            </a>
            <a href="Data Search.php" class="nav-item">
                <i class="fas fa-search nav-icon"></i>
                <span class="nav-text">Data Search</span>
            </a>
            <a href="Claims.php" class="nav-item">
                <i class="fas fa-file-invoice-dollar nav-icon"></i>
                <span class="nav-text">Claims</span>
            </a>
            <a href="Report.php" class="nav-item">
                <i class="fas fa-file-alt nav-icon"></i>
                <span class="nav-text">Reports</span>
            </a>
            <a href="../index.php?logout=true" class="nav-item">
                <i class="fas fa-sign-out-alt nav-icon"></i>
                <span class="nav-text">Logout</span>
            </a>
        </nav>
        
        <div class="sidebar-footer">
            &copy; <?= date('Y') ?> Insurance AI Portal
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="page-header">
            <div class="page-title">
                <div class="icon">
                    <i class="fas fa-users"></i>
                </div>
                <h1>Client Management</h1>
            </div>
        </div>
        
        <!-- Add/Edit Client Form -->
        <div class="client-card">
            <div class="card-header">
                <h2 id="formTitle">Add New Client</h2>
            </div>
            
            <form id="clientForm" method="POST">
                <input type="hidden" name="id" id="clientId">
                
                <div class="form-row">
                    <div class="form-col">
                        <div class="form-group">
                            <label for="firstName" class="form-label">First Name</label>
                            <input type="text" id="firstName" name="firstName" required class="form-control">
                        </div>
                    </div>
                    <div class="form-col">
                        <div class="form-group">
                            <label for="lastName" class="form-label">Last Name</label>
                            <input type="text" id="lastName" name="lastName" required class="form-control">
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="email" class="form-label">Email Address</label>
                    <input type="email" id="email" name="email" required class="form-control">
                </div>
                
                <div class="form-row">
                    <div class="form-col">
                        <div class="form-group">
                            <label for="phone" class="form-label">Phone Number</label>
                            <input type="tel" id="phone" name="phone" required class="form-control">
                        </div>
                    </div>
                    <div class="form-col">
                        <div class="form-group">
                            <label for="policyType" class="form-label">Policy Type</label>
                            <select id="policyType" name="policyType" required class="form-select">
                                <option value="">Select Policy Type</option>
                                <option value="health">Health Insurance</option>
                                <option value="life">Life Insurance</option>
                                <option value="auto">Auto Insurance</option>
                                <option value="home">Home Insurance</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="address" class="form-label">Address</label>
                    <input type="text" id="address" name="address" required class="form-control">
                </div>
                
                <div class="form-row">
                    <div class="form-col">
                        <div class="form-group">
                            <label for="city" class="form-label">City</label>
                            <input type="text" id="city" name="city" required class="form-control">
                        </div>
                    </div>
                    <div class="form-col">
                        <div class="form-group">
                            <label for="paymentMode" class="form-label">Payment Mode</label>
                            <select id="paymentMode" name="paymentMode" required class="form-select">
                                <option value="">Select Payment Mode</option>
                                <option value="monthly">Monthly</option>
                                <option value="quarterly">Quarterly</option>
                                <option value="annually">Annually</option>
                                <option value="oneTime">One-Time</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="btn-group">
                    <button type="button" onclick="resetForm()" class="btn btn-secondary">Clear Form</button>
                    <button type="submit" class="btn btn-primary">Save Client</button>
                </div>
            </form>
        </div>
        
        <!-- Clients List -->
        <div class="client-card">
            <div class="card-header">
                <h2>Client List</h2>
            </div>
            
            <div class="table-wrapper">
                <table class="clients-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Policy Type</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($clients) > 0): ?>
                            <?php foreach ($clients as $client): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($client['id']); ?></td>
                                    <td><?php echo htmlspecialchars($client['firstName'] . ' ' . $client['lastName']); ?></td>
                                    <td><?php echo htmlspecialchars($client['email']); ?></td>
                                    <td><?php echo htmlspecialchars($client['phone']); ?></td>
                                    <td><?php echo htmlspecialchars($client['policyType']); ?></td>
                                    <td class="action-buttons">
                                        <button onclick="editClient(<?php echo htmlspecialchars(json_encode($client)); ?>)" class="btn btn-warning btn-sm">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <a href="?delete=<?php echo $client['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this client?')">
                                            <i class="fas fa-trash"></i> Delete
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" style="text-align: center;">No clients found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <script>
        function editClient(client) {
            document.getElementById('formTitle').textContent = 'Edit Client';
            document.getElementById('clientId').value = client.id;
            document.getElementById('firstName').value = client.firstName;
            document.getElementById('lastName').value = client.lastName;
            document.getElementById('email').value = client.email;
            document.getElementById('phone').value = client.phone;
            document.getElementById('policyType').value = client.policyType;
            document.getElementById('address').value = client.address;
            document.getElementById('city').value = client.city;
            document.getElementById('paymentMode').value = client.paymentMode;
            
            // Scroll to form
            document.querySelector('.client-card').scrollIntoView({behavior: 'smooth'});
        }
        
        function resetForm() {
            document.getElementById('formTitle').textContent = 'Add New Client';
            document.getElementById('clientForm').reset();
            document.getElementById('clientId').value = '';
        }
    </script>
</body>
</html>