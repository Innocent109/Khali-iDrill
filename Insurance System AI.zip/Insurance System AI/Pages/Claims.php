<?php
// Database Connection
$servername = "localhost"; $username = "root"; $password = ""; $dbname = "insurance_ai";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Insert Claim
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submitClaim'])) {
    $policy_number = $_POST['policy_number'];
    $claim_type = $_POST['claim_type'];
    $incident_date = $_POST['incident_date'];
    $claim_amount = $_POST['claim_amount'];
    $description = $_POST['description'];
    $client_id = $_POST['client_id'];

    $stmt = $conn->prepare("INSERT INTO claims (policy_number, claim_type, incident_date, claim_amount, description, client_id) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssi", $policy_number, $claim_type, $incident_date, $claim_amount, $description, $client_id);

    if (!$stmt->execute()) {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Update Claim
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['updateClaim'])) {
    $claimId = intval($_POST['claimId']);
    $policy_number = $_POST['policy_number'];
    $claim_type = $_POST['claim_type'];
    $incident_date = $_POST['incident_date'];
    $claim_amount = $_POST['claim_amount'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("UPDATE claims SET policy_number = ?, claim_type = ?, incident_date = ?, claim_amount = ?, description = ? WHERE id = ?");
    $stmt->bind_param("sssssi", $policy_number, $claim_type, $incident_date, $claim_amount, $description, $claimId);

    if ($stmt->execute()) {
        echo "Claim updated successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Delete Claim
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deleteClaim'])) {
    $claimId = intval($_POST['claimId']);

    $stmt = $conn->prepare("DELETE FROM claims WHERE id = ?");
    $stmt->bind_param("i", $claimId);

    if ($stmt->execute()) {
        echo "Claim deleted successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

// Fetch Data
function fetchClaims($conn) {
    $claims = [];
    $stmt = $conn->prepare("SELECT claims.*, clients.firstName, '' , clients.lastName FROM claims INNER JOIN clients ON claims.client_id = clients.id ORDER BY claims.submission_date DESC");
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $claims[] = $row;
    }
    $stmt->close();
    return $claims;
}

function fetchPolicyNumbers($conn) {
    $policyNumbers = [];
    $stmt = $conn->prepare("SELECT policy_number FROM policies");
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $policyNumbers[] = $row['policy_number'];
    }
    $stmt->close();
    return $policyNumbers;
}

function fetchClients($conn) {
    $clients = [];
    $stmt = $conn->prepare("SELECT id, clients.firstName, clients.lastName FROM clients");
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $clients[] = $row;
    }
    $stmt->close();
    return $clients;
}

$policyNumbers = fetchPolicyNumbers($conn);
$clients = fetchClients($conn);
$claims = fetchClaims($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance | MIS | Claims</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../Css/payments.css"> 
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-container">
                <img src="../Images/Logo.png" alt="Insurance AI Logo" class="logo">
                <span class="company-name">Insurance AI</span>
            </div>
        </div>
        <nav class="navigation">
            <a href="../dashboard.php" class="nav-item">
                <i class="fas fa-tachometer-alt nav-icon"></i>
                <span class="nav-text">Dashboard</span>
            </a>
            <a href="clients.php" class="nav-item">
                <i class="fas fa-users nav-icon"></i>
                <span class="nav-text">Clients</span>
            </a>
            <a href="payments.php" class="nav-item">
                <i class="fas fa-money-check-dollar nav-icon"></i>
                <span class="nav-text">Payments</span>
            </a>
            <a href="policies.php" class="nav-item">
                <i class="fas fa-book nav-icon"></i>
                <span class="nav-text">Policies</span>
            </a>
            <a href="analysis.php" class="nav-item">
                <i class="fas fa-chart-bar nav-icon"></i>
                <span class="nav-text">Analysis</span>
            </a>
            <a href="Data Search.php" class="nav-item">
                <i class="fas fa-search nav-icon"></i>
                <span class="nav-text">Data Search</span>
            </a>
            <a href="Claims.php" class="nav-item active">
                <i class="fas fa-file-invoice-dollar nav-icon"></i>
                <span class="nav-text">Claims</span>
            </a>
            <a href="Report.php" class="nav-item">
                <i class="fas fa-file-alt nav-icon"></i>
                <span class="nav-text">Reports</span>
            </a>
            <a href="../index.php?logout=true" class="nav-item">
                <i class="fas fa-sign-out-alt nav-icon"></i>
                <span class="nav-text">Logout</span>
            </a>
        </nav>
        
        <div class="sidebar-footer">
            &copy; <?= date('Y') ?> Insurance AI Portal
        </div>
    </aside>
        <!-- Main Content -->
        <div class="main-content">
            <!-- Updated Page Header with Blue Card and White Title -->
            <div class="page-header-card">
                <div class="d-flex align-items-center">
                    <div class="page-header-icon">
                        <i class="fas fa-file-medical-alt"></i>
                    </div>
                    <h1 class="page-title">Claims Management</h1>
                </div>
            </div>

            <!-- Claim Form Card with Blue Header and White Text -->
            <div class="card mb-4">
                <div class="card-header">
                    <h2 class="m-0" id="formTitle">Create New Claim</h2>
                </div>
                <div class="card-body">
                    <form method="POST" class="mb-4">
                        <input type="hidden" name="action" id="form-action" value="add_claim">
                        <input type="hidden" name="claim_id" id="claim-id">
                        
                        <div class="row g-4">
                            <!-- Policy Number Selection -->
                            <div class="col-md-6">
                                <label for="policy-number" class="form-label">Policy Number:</label>
                                <select name="policy_number" id="policy-number" required class="form-select">
                                    <option value="">Select Policy Number</option>
                                    <?php foreach ($policyNumbers as $policy): ?>
                                        <option value="<?= htmlspecialchars($policy) ?>"><?= htmlspecialchars($policy) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Client Selection -->
                            <div class="col-md-6">
                                <label for="client-id" class="form-label">Client:</label>
                                <select name="client_id" id="client-id" required class="form-select">
                                    <option value="">Select Client</option>
                                    <?php foreach ($clients as $client): ?>
                                        <option value="<?= $client['id'] ?>"><?= htmlspecialchars($client['lastName']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <!-- Claim Type -->
                            <div class="col-md-6">
                                <label for="claim-type" class="form-label">Claim Type:</label>
                                <input type="text" name="claim_type" id="claim-type" class="form-control" placeholder="Claim Type" required>
                            </div>

                            <!-- Incident Date -->
                            <div class="col-md-6">
                                <label for="incident-date" class="form-label">Incident Date:</label>
                                <input type="date" name="incident_date" id="incident-date" class="form-control" required>
                            </div>

                            <!-- Claim Amount -->
                            <div class="col-md-6">
                                <label for="claim-amount" class="form-label">Claim Amount:</label>
                                <div class="input-group">
                                    <span class="input-group-text">MWK</span>
                                    <input type="number" name="claim_amount" id="claim-amount" class="form-control" step="0.01" placeholder="0.00" required>
                                </div>
                            </div>

                            <!-- Claim Description -->
                            <div class="col-md-6">
                                <label for="description" class="form-label">Claim Description:</label>
                                <textarea name="description" id="description" class="form-control" placeholder="Description" required rows="3"></textarea>
                            </div>

                            <!-- Form Buttons -->
                            <div class="col-12 d-flex justify-content-between mt-4">
                                <button type="submit" name="submitClaim" class="btn btn-primary">
                                    <i class="fas fa-paper-plane me-2"></i>Submit Claim
                                </button>
                                <button type="button" onclick="resetForm()" class="btn btn-secondary" id="resetButton" style="display: none;">
                                    <i class="fas fa-undo me-2"></i>Cancel
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Claims Table Card with Blue Header and White Text -->
            <div class="card">
                <div class="card-header">
                    <h2 class="m-0">Claims Records</h2>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Client Name</th>
                                    <th>Policy Number</th>
                                    <th>Claim Type</th>
                                    <th>Incident Date</th>
                                    <th>Claim Amount</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($claims as $claim): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($claim['lastName']) ?></td>
                                        <td><?= htmlspecialchars($claim['policy_number']) ?></td>
                                        <td>
                                            <?php 
                                            $badgeClass = 'badge-other';
                                            $claimType = strtolower($claim['claim_type']);
                                            if (strpos($claimType, 'health') !== false) {
                                                $badgeClass = 'badge-health';
                                            } elseif (strpos($claimType, 'life') !== false) {
                                                $badgeClass = 'badge-life';
                                            } elseif (strpos($claimType, 'auto') !== false || strpos($claimType, 'car') !== false) {
                                                $badgeClass = 'badge-auto';
                                            } elseif (strpos($claimType, 'home') !== false || strpos($claimType, 'property') !== false) {
                                                $badgeClass = 'badge-home';
                                            }
                                            ?>
                                            <span class="badge <?= $badgeClass ?>"><?= htmlspecialchars($claim['claim_type']) ?></span>
                                        </td>
                                        <td><?= date('M d, Y', strtotime($claim['incident_date'])) ?></td>
                                        <td>$<?= number_format($claim['claim_amount'], 2) ?></td>
                                        <td>
                                            <button 
                                                onclick="editClaim(
                                                    '<?= $claim['id'] ?>',
                                                    '<?= $claim['policy_number'] ?>',
                                                    '<?= $claim['client_id'] ?>',
                                                    '<?= $claim['claim_type'] ?>',
                                                    '<?= $claim['incident_date'] ?>',
                                                    '<?= $claim['claim_amount'] ?>',
                                                    '<?= $claim['description'] ?>'
                                                )" 
                                                class="btn btn-sm btn-primary me-2">
                                                <i class="fas fa-edit me-1"></i>Edit
                                            </button>
                                            
                                            <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this claim?');">
                                                <input type="hidden" name="claimId" value="<?= $claim['id'] ?>">
                                                <button type="submit" name="deleteClaim" class="btn btn-sm btn-danger">
                                                    <i class="fas fa-trash-alt me-1"></i>Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        function editClaim(id, policyNumber, clientId, claimType, incidentDate, claimAmount, description) {
            document.getElementById('form-action').value = 'update_claim';
            document.getElementById('claim-id').value = id;
            document.getElementById('policy-number').value = policyNumber;
            document.getElementById('client-id').value = clientId;
            document.getElementById('claim-type').value = claimType;
            document.getElementById('incident-date').value = incidentDate;
            document.getElementById('claim-amount').value = claimAmount;
            document.getElementById('description').value = description;
            
            document.getElementById('formTitle').textContent = 'Edit Claim';
            document.getElementById('resetButton').style.display = 'block';
            
            document.querySelector('html, body').scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }
        
        function resetForm() {
            document.getElementById('form-action').value = 'add_claim';
            document.getElementById('claim-id').value = '';
            document.getElementById('policy-number').selectedIndex = 0;
            document.getElementById('client-id').selectedIndex = 0;
            document.getElementById('claim-type').value = '';
            document.getElementById('incident-date').value = '';
            document.getElementById('claim-amount').value = '';
            document.getElementById('description').value = '';
            
            document.getElementById('formTitle').textContent = 'Create New Claim';
            document.getElementById('resetButton').style.display = 'none';
        }
    </script>
</body>
</html>