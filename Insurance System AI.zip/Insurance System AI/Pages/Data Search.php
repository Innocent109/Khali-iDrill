<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "insurance_ai";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all clients
$clients = [];
$sqlClients = "SELECT id, CONCAT(firstName, ' ', lastName) AS name FROM clients";
$resultClients = $conn->query($sqlClients);
if ($resultClients && $resultClients->num_rows > 0) {
    while ($row = $resultClients->fetch_assoc()) {
        $clients[] = $row;
    }
}

// Fetch client data
$clientData = [];
$paymentsData = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['client_id'])) {
    $clientId = (int) $_POST['client_id'];

    // Client details query
    $sql = "
        SELECT c.id AS client_id, CONCAT(c.firstName, ' ', c.lastName) AS client_name, c.email, c.phone,
               policies.id, policies.policy_type, policies.coverage_amount, policies.policy_number,
               claims.id AS claim_id, claims.description, claims.claim_amount, claims.incident_date
        FROM clients c
        LEFT JOIN policies ON c.id = policies.client_name
        LEFT JOIN claims ON c.id = claims.client_id
        WHERE c.id = $clientId;
    ";

    $result = $conn->query($sql);
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $clientData[] = $row;
        }
    }

    // Payments query
    $sqlPayments = "
        SELECT id, payment_date, amount, payment_method, payment_status 
        FROM payments 
        WHERE client_id = $clientId
        ORDER BY payment_date DESC;
    ";

    $resultPayments = $conn->query($sqlPayments);
    if ($resultPayments && $resultPayments->num_rows > 0) {
        while ($row = $resultPayments->fetch_assoc()) {
            $paymentsData[] = $row;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance Data Search</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        @font-face {
            font-family: 'Arial Rounded MT Bold';
            src: url('https://db.onlinewebfonts.com/t/9b260ccc029e8b9ca8a0322f6b9d1fbd.woff2') format('woff2');
            font-weight: bold;
            font-style: normal;
        }
        
        body {
            font-family: 'Arial Rounded MT Bold', Arial, sans-serif;
            background-color: #f8fafc;
            color: #0d3c84;
        }
        
        .header-blue {
            background-color: #0d6efd;
            color: white;
        }
        
        .card {
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border: none;
        }
        
        .card-header {
            background-color: #0d6efd;
            color: white;
            border-radius: 10px 10px 0 0 !important;
            padding: 15px 20px;
        }
        
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }
        
        .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0a58ca;
        }
        
        table {
            border-collapse: separate;
            border-spacing: 0;
            width: 100%;
        }
        
        th {
            background-color: #0d6efd;
            color: white;
            position: sticky;
            top: 0;
        }
        
        td, th {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        
        tr:hover {
            background-color: rgba(13, 110, 253, 0.05);
        }
        
        .sidebar {
            width: 250px;
            background-color: #0d3c84;
            color: white;
            min-height: 100vh;
        }
        
        .sidebar-header {
            padding: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-menu {
            list-style: none;
            padding: 0;
        }
        
        .sidebar-item {
            padding: 12px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        }
        
        .sidebar-link {
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            display: flex;
            align-items: center;
        }
        
        .sidebar-link:hover {
            color: white;
        }
        
        .sidebar-icon {
            width: 24px;
            margin-right: 10px;
            text-align: center;
        }
        
        .badge-paid {
            background-color: #28a745;
            color: white;
        }
        
        .badge-pending {
            background-color: #ffc107;
            color: #212529;
        }
        
        .badge-failed {
            background-color: #dc3545;
            color: white;
        }
    </style>
</head>
<body>
    <div class="d-flex">
        <!-- Sidebar Navigation -->
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="d-flex align-items-center">
                    <img src="../Images/Logo.png" alt="Company Logo" height="40" class="me-2">
                    <span class="fs-5">Insurance AI</span>
                </div>
            </div>
            
            <ul class="sidebar-menu">
                <li class="sidebar-item">
                    <a href="../dashboard.php" class="sidebar-link">
                        <i class="fas fa-tachometer-alt sidebar-icon"></i>
                        Dashboard
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="clients.php" class="sidebar-link">
                        <i class="fas fa-users sidebar-icon"></i>
                        Clients
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="payments.php" class="sidebar-link">
                        <i class="fas fa-credit-card sidebar-icon"></i>
                        Payments
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="policies.php" class="sidebar-link">
                        <i class="fas fa-file-contract sidebar-icon"></i>
                        Policies
                    </a>
                </li>
                <li class="sidebar-item active">
                    <a href="analysis.php" class="sidebar-link">
                        <i class="fas fa-chart-line sidebar-icon"></i>
                        Analysis
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="Data Search.php" class="sidebar-link">
                        <i class="fas fa-search sidebar-icon"></i>
                        Data Search
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="Claims.php" class="sidebar-link">
                        <i class="fas fa-file-medical-alt sidebar-icon"></i>
                        Claims
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="Report.php" class="sidebar-link">
                        <i class="fas fa-file-chart-line sidebar-icon"></i>
                        Reports
                    </a>
                </li>
                <li class="sidebar-item">
                    <a href="../index.php?logout=true" class="sidebar-link">
                        <i class="fas fa-sign-out-alt sidebar-icon"></i>
                        Logout
                    </a>
                </li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content flex-grow-1 p-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div class="d-flex align-items-center">
                    <h1 class="m-0 text-blue-dark">Client Data Search</h1>
                </div>
            </div>
            
            <div class="card mb-4">
                <div class="card-header">
                    <h2 class="m-0"><i class="fas fa-search me-2"></i>Search Client</h2>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="row">
                            <div class="col-md-8 mb-3">
                                <label for="client_id" class="form-label">Select Client:</label>
                                <select name="client_id" id="client_id" class="form-select" required>
                                    <option value="" disabled selected>Select a client</option>
                                    <?php foreach ($clients as $client): ?>
                                        <option value="<?php echo htmlspecialchars($client['id']); ?>">
                                            <?php echo htmlspecialchars($client['name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-search me-2"></i>Search
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <?php if (!empty($clientData)): ?>
                <!-- Client Details -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h2 class="m-0"><i class="fas fa-user me-2"></i>Customer Details</h2>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td><?php echo htmlspecialchars($clientData[0]['client_name']); ?></td>
                                        <td><?php echo htmlspecialchars($clientData[0]['email']); ?></td>
                                        <td><?php echo htmlspecialchars($clientData[0]['phone']); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Policies -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h2 class="m-0"><i class="fas fa-file-contract me-2"></i>Policies</h2>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Policy ID</th>
                                        <th>Policy Type</th>
                                        <th>Coverage Amount</th>
                                        <th>Policy Number</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($clientData as $data): ?>
                                        <?php if ($data['id']): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($data['id']); ?></td>
                                                <td><?php echo htmlspecialchars($data['policy_type']); ?></td>
                                                <td><?php echo htmlspecialchars($data['coverage_amount']); ?></td>
                                                <td><?php echo htmlspecialchars($data['policy_number'] ?? 'N/A'); ?></td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Claims -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h2 class="m-0"><i class="fas fa-file-medical-alt me-2"></i>Claims</h2>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Claim ID</th>
                                        <th>Description</th>
                                        <th>Amount Claimed</th>
                                        <th>Claim Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($clientData as $data): ?>
                                        <?php if ($data['claim_id']): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($data['claim_id']); ?></td>
                                                <td><?php echo htmlspecialchars($data['description']); ?></td>
                                                <td><?php echo htmlspecialchars($data['claim_amount']); ?></td>
                                                <td><?php echo htmlspecialchars($data['incident_date']); ?></td>
                                            </tr>
                                        <?php endif; ?>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Payments -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h2 class="m-0"><i class="fas fa-money-bill-wave me-2"></i>Payment History</h2>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Payment ID</th>
                                        <th>Date</th>
                                        <th>Amount</th>
                                        <th>Method</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (!empty($paymentsData)): ?>
                                        <?php foreach ($paymentsData as $payment): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($payment['id']); ?></td>
                                                <td><?php echo htmlspecialchars($payment['payment_date']); ?></td>
                                                <td><?php echo htmlspecialchars($payment['amount']); ?></td>
                                                <td><?php echo htmlspecialchars($payment['payment_method']); ?></td>
                                                <td>
                                                    <?php 
                                                    $statusClass = '';
                                                    if ($payment['payment_status'] === 'Paid') {
                                                        $statusClass = 'badge-paid';
                                                    } elseif ($payment['payment_status'] === 'Pending') {
                                                        $statusClass = 'badge-pending';
                                                    } else {
                                                        $statusClass = 'badge-failed';
                                                    }
                                                    ?>
                                                    <span class="badge rounded-pill <?php echo $statusClass; ?>">
                                                        <?php echo htmlspecialchars($payment['payment_status']); ?>
                                                    </span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="5" class="text-center">No payment records found</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="text-center mt-4">
                    <a href="report.php" class="btn btn-primary">
                        <i class="fas fa-file-pdf me-2"></i>Generate Report
                    </a>
                </div>
            <?php elseif ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
                <div class="alert alert-warning">
                    No data found for the selected client.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>