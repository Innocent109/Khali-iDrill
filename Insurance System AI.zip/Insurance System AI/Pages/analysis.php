<?php
session_start();

// Database configuration
$dbHost = 'localhost';
$dbUser = 'root';
$dbPass = '';
$dbName = 'insurance_ai';

try {
    // Create PDO connection
    $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create uploads directory if it doesn't exist
    if (!file_exists('uploads')) {
        mkdir('uploads', 0777, true);
    }

    // Fetch clients from database
    $clientsQuery = $pdo->query("SELECT id, CONCAT(firstName, ' ', lastName) AS name FROM clients");
    $clients = $clientsQuery->fetchAll(PDO::FETCH_ASSOC);

    // Initialize variables
    $selectedClientId = null;
    $clientData = null;
    $aiAnalysis = null;
    $selectedPlatform = null;
    $uploadedImage = null;
    $error = '';
    $success = '';

    // Process form submissions
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['client_id'])) {
            // Client selected
            $selectedClientId = $_POST['client_id'];
            
            // Get client details
            $stmt = $pdo->prepare("SELECT * FROM clients WHERE id = ?");
            $stmt->execute([$selectedClientId]);
            $clientData = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Get client's claims history
            $claimsStmt = $pdo->prepare("SELECT * FROM claims WHERE client_id = ? ORDER BY incident_date DESC");
            $claimsStmt->execute([$selectedClientId]);
            $claimsHistory = $claimsStmt->fetchAll(PDO::FETCH_ASSOC);
            
            // Prepare client context for AI analysis
            $clientContext = [
                'id' => $clientData['id'],
                'name' => $clientData['firstName'] . ' ' . $clientData['lastName'],
                'total_claims' => count($claimsHistory),
                'last_claim' => !empty($claimsHistory) ? $claimsHistory[0]['incident_date'] : 'Never',
                'average_claim' => !empty($claimsHistory) ? 
                    array_sum(array_column($claimsHistory, 'claim_amount')) / count($claimsHistory) : 0
            ];
            
            // Store in session for AI platforms to access
            $_SESSION['client_context'] = $clientContext;
            $_SESSION['claims_history'] = $claimsHistory;
            
            // Handle file upload if present
           // Handle file upload if present
        if (isset($_FILES['damage_image']) && $_FILES['damage_image']['error'] === UPLOAD_ERR_OK) {
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
            $maxFileSize = 5 * 1024 * 1024; // 5MB
            
            $file = $_FILES['damage_image'];
            
            if (in_array($file['type'], $allowedTypes)) {
                if ($file['size'] <= $maxFileSize) {
                    $filename = uniqid() . '_' . basename($file['name']);
                    $targetPath = 'uploads/' . $filename;
                    
                    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
                        $uploadedImage = $targetPath;
                        $_SESSION['uploaded_image'] = $uploadedImage;
                        $success = "Image uploaded successfully!";
                    } else {
                        $error = "Failed to move uploaded file.";
                    }
                } else {
                    $error = "File size exceeds maximum allowed (5MB).";
                }
            } else {
                $error = "Only JPG, PNG, and GIF files are allowed.";
            }
        }
            
        } elseif (isset($_POST['ai_platform'])) {
            // AI platform selected
            $selectedPlatform = $_POST['ai_platform'];
            
            if (!isset($_SESSION['client_context'])) {
                $error = "Please select a client first.";
            } else {
                $clientContext = $_SESSION['client_context'];
                $claimsHistory = $_SESSION['claims_history'];
                $uploadedImage = $_SESSION['uploaded_image'] ?? null;
                
                if ($uploadedImage && file_exists($uploadedImage)) {
                    // Simulate AI analysis with image
                    $aiAnalysis = simulateAIAnalysis($selectedPlatform, $clientContext, $claimsHistory, $uploadedImage);
                } else {
                    $error = "No damage image uploaded for analysis.";
                }
            }
        }
    }

} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

/**
 * Simulates AI analysis from different platforms with image
 */
function simulateAIAnalysis($platform, $client, $claims, $imagePath) {
    $analysis = [
        'platform' => $platform,
        'timestamp' => date('Y-m-d H:i:s'),
        'risk_assessment' => '',
        'key_findings' => [],
        'recommendations' => [],
        'image_analysis' => []
    ];
    
    $totalClaims = $client['total_claims'];
    $avgClaim = $client['average_claim'];
    
    // Simulate image analysis
    $imageSize = getimagesize($imagePath);
    $imageAnalysis = [
        'Damage Detected' => 'Yes',
        'Damage Type' => simulateDamageType($imagePath),
        'Severity' => rand(1, 10) . '/10',
        'Image Resolution' => $imageSize[0] . 'x' . $imageSize[1],
        'Color Analysis' => simulateColorAnalysis($imagePath)
    ];
    
    $analysis['image_analysis'] = $imageAnalysis;
    
    switch ($platform) {
        case 'chatgpt':
            $analysis['risk_assessment'] = "Based on visual analysis and the client's history of $totalClaims claims, we assess this as a " . 
                                         ($totalClaims > 3 ? "high" : ($totalClaims > 7 ? "moderate" : "low")) . " risk case.";
            
            $analysis['key_findings'] = [
                "Damage type: " . $imageAnalysis['Damage Type'],
                "Severity level: " . $imageAnalysis['Severity'],
                "Client has filed $totalClaims claims in total",
                "Average claim amount: MWK" . number_format($avgClaim, 2)
            ];
            
            $analysis['recommendations'] = [
                "Recommend " . ($imageAnalysis['Severity'] > 5 ? "immediate" : "scheduled") . " inspection",
                "Consider " . ($totalClaims > 2 ? "additional" : "standard") . " verification for this claim",
                "Review similar past claims for consistency"
            ];
            break;
            
        case 'deepseek':
            $analysis['risk_assessment'] = "Pattern analysis reveals this damage is " . 
                                         ($imageAnalysis['Severity'] > 7 ? "likely" : "possibly") . 
                                         " related to " . ($totalClaims > 2 ? "previous" : "new") . " issues.";
            
            $analysis['key_findings'] = [
                "Primary damage: " . $imageAnalysis['Damage Type'],
                "Color patterns: " . $imageAnalysis['Color Analysis'],
                "Claim frequency: " . ($totalClaims > 3 ? "High" : "Normal"),
                "Financial exposure: MWK" . number_format($totalClaims * $avgClaim, 2) . " total"
            ];
            
            $analysis['recommendations'] = [
                "Cross-reference with " . ($totalClaims > 1 ? "previous" : "industry") . " damage patterns",
                "Consider " . ($imageAnalysis['Severity'] > 5 ? "professional" : "standard") . " assessment",
                "Review coverage for this damage type"
            ];
            break;
            
        case 'claude':
            $analysis['risk_assessment'] = "Ethical review indicates this damage appears " . 
                                         ($imageAnalysis['Severity'] > 6 ? "serious" : "manageable") . 
                                         " with " . ($totalClaims > 2 ? "potential" : "no") . " consistency issues.";
            
            $analysis['key_findings'] = [
                "Damage characteristics: " . $imageAnalysis['Damage Type'],
                "Visual severity: " . $imageAnalysis['Severity'],
                "Claims history shows " . ($totalClaims > 2 ? "multiple" : "limited") . " incidents",
                "Most recent claim: " . $client['last_claim']
            ];
            
            $analysis['recommendations'] = [
                "Client education on " . ($imageAnalysis['Severity'] > 5 ? "prevention" : "coverage"),
                "Review " . ($totalClaims > 1 ? "all" : "this") . " damage reports",
                "Consider " . ($imageAnalysis['Severity'] > 7 ? "immediate" : "standard") . " processing"
            ];
            break;
    }
    
    return $analysis;
}

/**
 * Simulates damage type based on filename
 */
function simulateDamageType($filename) {
    $types = ['Collision', 'Hail Damage', 'Accident', 'Fire', 'Vandalism', 'Wear and Tear'];
    return $types[rand(0, count($types)-1)];
}

/**
 * Simulates color analysis based on filename
 */
function simulateColorAnalysis($filename) {
    $colors = ['Red dominant', 'Blue tones', 'Mixed colors', 'Dark pattern', 'Light pattern'];
    return $colors[rand(0, count($colors)-1)];
}

/**
 * Redirects to the selected AI platform with client context
 */
function redirectToAIPlatform($platform) {
    if (!isset($_SESSION['client_context']) || !isset($_SESSION['uploaded_image'])) {
        return false;
    }
    
    $clientId = $_SESSION['client_context']['id'];
    $context = base64_encode(json_encode([
        'client' => $_SESSION['client_context'],
        'image_path' => $_SESSION['uploaded_image']
    ]));
    
    switch ($platform) {
        case 'chatgpt':
            $url = "https://chat.openai.com/?insurance_client=$clientId&context=$context";
            break;
        case 'deepseek':
            $url = "https://www.deepseek.com/analyze?client_id=$clientId&insurance_context=$context";
            break;
        case 'claude':
            $url = "https://claude.ai/analysis?insurance_client=$clientId&data=$context";
            break;
        default:
            return false;
    }
    
    header("Location: $url");
    exit;
}

// Handle AI platform redirect
if (isset($_GET['ai_redirect'])) {
    redirectToAIPlatform($_GET['ai_redirect']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance AI Analysis | MIS</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../Css/analysis.css">
</head>
<body>
    <!-- Sidebar Navigation -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="d-flex align-items-center">
                <img src="../Images/Logo.png" alt="Company Logo" height="40" class="me-2">
                <span class="fs-5">Insurance AI</span>
            </div>
        </div>
        
        <ul class="sidebar-menu">
            <li class="sidebar-item">
                <a href="../dashboard.php" class="sidebar-link">
                    <i class="fas fa-tachometer-alt sidebar-icon"></i>
                    Dashboard
                </a>
            </li>
            <li class="sidebar-item">
                <a href="clients.php" class="sidebar-link">
                    <i class="fas fa-users sidebar-icon"></i>
                    Clients
                </a>
            </li>
            <li class="sidebar-item">
                <a href="payments.php" class="sidebar-link">
                    <i class="fas fa-credit-card sidebar-icon"></i>
                    Payments
                </a>
            </li>
            <li class="sidebar-item">
                <a href="policies.php" class="sidebar-link">
                    <i class="fas fa-file-contract sidebar-icon"></i>
                    Policies
                </a>
            </li>
            <li class="sidebar-item active">
                <a href="analysis.php" class="sidebar-link">
                    <i class="fas fa-chart-line sidebar-icon"></i>
                    Analysis
                </a>
            </li>
            <li class="sidebar-item">
                <a href="Data Search.php" class="sidebar-link">
                    <i class="fas fa-search sidebar-icon"></i>
                    Data Search
                </a>
            </li>
            <li class="sidebar-item">
                <a href="Claims.php" class="sidebar-link">
                    <i class="fas fa-file-medical-alt sidebar-icon"></i>
                    Claims
                </a>
            </li>
            <li class="sidebar-item">
                <a href="Report.php" class="sidebar-link">
                    <i class="fas fa-file-chart-line sidebar-icon"></i>
                    Reports
                </a>
            </li>
            <li class="sidebar-item">
                <a href="../index.php?logout=true" class="sidebar-link">
                    <i class="fas fa-sign-out-alt sidebar-icon"></i>
                    Logout
                </a>
            </li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container-fluid p-0">
            <!-- Header with Logo -->
            <header class="bg-blue-primary text-white p-3 shadow-sm">
                <div class="container">
                    <div class="d-flex justify-content-between align-items-center">
                        <h1 class="m-0">Analysis</h1>
                    </div>
                </div>
            </header>
            
            <!-- Main Content Area -->
            <div class="container py-4">
                <?php if ($error): ?>
                    <div class="alert alert-danger mb-4">
                        <?= $error ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($success): ?>
                    <div class="alert alert-success mb-4">
                        <?= $success ?>
                    </div>
                <?php endif; ?>
                
                <!-- Client and Image Upload Card -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h2 class="m-0"><i class="fas fa-upload me-2"></i>Upload Damage Image</h2>
                    </div>
                    <div class="card-body">
                        <form method="POST" enctype="multipart/form-data">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="clientSelect" class="form-label">Select Client:</label>
                                    <select name="client_id" id="clientSelect" class="form-select" required>
                                        <option value="" selected disabled>Select a client</option>
                                        <?php foreach ($clients as $client): ?>
                                            <option value="<?= $client['id'] ?>" <?= ($selectedClientId == $client['id']) ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($client['name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Upload Damage Image:</label>
                                    <div class="file-upload" onclick="document.getElementById('damageImage').click()">
                                        <input type="file" name="damage_image" id="damageImage" class="d-none" accept="image/*" onchange="previewImage(this)">
                                        <i class="fas fa-cloud-upload-alt fa-2x text-blue-primary mb-2"></i>
                                        <p class="mb-1">Click to upload image</p>
                                        <small class="text-muted">JPG, PNG, or GIF (Max 5MB)</small>
                                    </div>
                                    <img id="imagePreview" class="image-preview mt-3" alt="Image preview">
                                </div>
                            </div>
                            
                            <div class="text-end">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i>Save and Continue
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
                
                <?php if ($selectedClientId && $uploadedImage): ?>
                <!-- Image Preview and AI Selection -->
                <div class="card mb-4">
                    <div class="card-header">
                        <h2 class="m-0"><i class="fas fa-image me-2"></i>Damage Image Preview</h2>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="<?= $uploadedImage ?>" class="img-fluid rounded" alt="Uploaded damage image">
                                <p class="mt-2 text-muted">Uploaded image for analysis</p>
                            </div>
                            <div class="col-md-6">
                                <h4>Client Information</h4>
                                <p><strong>Name:</strong> <?= htmlspecialchars($clientData['firstName'] . ' ' . $clientData['lastName']) ?></p>
                                <p><strong>Total Claims:</strong> <?= count($claimsHistory) ?></p>
                                
                                <div class="mt-4">
                                    <h4>Analyze With:</h4>
                                    <div class="d-flex gap-2">
                                        <form method="POST" class="flex-grow-1">
                                            <input type="hidden" name="ai_platform" value="chatgpt">
                                            <button type="submit" class="btn btn-primary w-100">
                                                <i class="fab fa-openai me-2"></i>ChatGPT
                                            </button>
                                        </form>
                                        <form method="POST" class="flex-grow-1">
                                            <input type="hidden" name="ai_platform" value="deepseek">
                                            <button type="submit" class="btn btn-info w-100 text-white">
                                                <i class="fas fa-search me-2"></i>DeepSeek
                                            </button>
                                        </form>
                                        <form method="POST" class="flex-grow-1">
                                            <input type="hidden" name="ai_platform" value="claude">
                                            <button type="submit" class="btn btn-success w-100">
                                                <i class="fas fa-brain me-2"></i>Claude AI
                                            </button>
                                        </form>
                                    </div>
                                    
                                    <div class="mt-3">
                                        <p class="text-muted">Or analyze directly on their platforms:</p>
                                        <div class="d-flex gap-2">
                                            <a href="?ai_redirect=chatgpt" target="_blank" class="btn btn-outline-primary flex-grow-1">
                                                <i class="fas fa-external-link-alt me-2"></i>Open ChatGPT
                                            </a>
                                            <a href="?ai_redirect=deepseek" target="_blank" class="btn btn-outline-info flex-grow-1">
                                                <i class="fas fa-external-link-alt me-2"></i>Open DeepSeek
                                            </a>
                                            <a href="?ai_redirect=claude" target="_blank" class="btn btn-outline-success flex-grow-1">
                                                <i class="fas fa-external-link-alt me-2"></i>Open Claude
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <?php if ($aiAnalysis): ?>
                <!-- AI Analysis Report -->
                <div class="card">
                    <div class="card-header">
                        <h2 class="m-0"><i class="fas fa-file-alt me-2"></i>AI Analysis Report</h2>
                    </div>
                    <div class="card-body">
                        <div class="report-section p-4">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h4 class="text-blue-dark m-0">
                                    <i class="fas fa-robot me-2"></i>Findings from <?= ucfirst($aiAnalysis['platform']) ?>
                                </h4>
                                <button class="btn btn-primary" onclick="window.print()">
                                    <i class="fas fa-file-pdf me-2"></i>Generate Report
                                </button>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <h5 class="text-blue-primary"><i class="fas fa-chart-line me-2"></i>Risk Assessment</h5>
                                    <p><?= $aiAnalysis['risk_assessment'] ?></p>
                                    
                                    <h5 class="text-blue-primary mt-4"><i class="fas fa-exclamation-triangle me-2"></i>Key Findings</h5>
                                    <ul class="list-group list-group-flush">
                                        <?php foreach ($aiAnalysis['key_findings'] as $finding): ?>
                                            <li class="list-group-item"><?= $finding ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                    
                                    <h5 class="text-blue-primary mt-4"><i class="fas fa-lightbulb me-2"></i>Recommendations</h5>
                                    <ul class="list-group list-group-flush">
                                        <?php foreach ($aiAnalysis['recommendations'] as $recommendation): ?>
                                            <li class="list-group-item"><?= $recommendation ?></li>
                                        <?php endforeach; ?>
                                    </ul>
                                </div>
                                
                                <div class="col-md-6">
                                    <h5 class="text-blue-primary"><i class="fas fa-image me-2"></i>Image Analysis</h5>
                                    <table class="table table-bordered">
                                        <?php foreach ($aiAnalysis['image_analysis'] as $key => $value): ?>
                                            <tr>
                                                <th width="40%"><?= $key ?></th>
                                                <td><?= $value ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </table>
                                    
                                    <div class="text-center mt-3">
                                        <img src="<?= $uploadedImage ?>" class="img-fluid rounded" style="max-height: 200px;" alt="Analyzed image">
                                        <p class="text-muted mt-2">Analyzed damage image</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="alert alert-info mt-4">
                                <i class="fas fa-info-circle me-2"></i>
                                <strong>Note:</strong> This analysis was generated on <?= $aiAnalysis['timestamp'] ?> and should be reviewed by a qualified professional.
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Preview uploaded image
        function previewImage(input) {
            const preview = document.getElementById('imagePreview');
            if (input.files && input.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        
        // Generate PDF report
        function generatePDF() {
            alert('In a production environment, this would generate a PDF report with the analysis results.');
        }
    </script>
</body>
</html>