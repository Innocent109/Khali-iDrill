<?php
// Database Connection
$host = 'localhost'; $dbname = 'insurance_ai'; $username = 'root'; $password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (isset($data['action'])) {
        try {
            switch ($data['action']) {
                case 'add':
                    $stmt = $pdo->prepare("INSERT INTO payments (client_id, policy_type, amount, payment_date, payment_method, payment_status) VALUES (?, ?, ?, ?, ?, ?)");
                    $stmt->execute([
                        $data['client_id'],
                        $data['policy_type'],
                        $data['amount'],
                        $data['payment_date'],
                        $data['payment_method'],
                        $data['payment_status']
                    ]);
                    echo json_encode(['success' => true, 'message' => 'Payment recorded successfully']);
                    break;

                case 'update':
                    $stmt = $pdo->prepare("UPDATE payments SET client_id = ?, policy_type = ?, amount = ?, payment_date = ?, payment_method = ?, payment_status = ? WHERE id = ?");
                    $stmt->execute([
                        $data['client_id'],
                        $data['policy_type'],
                        $data['amount'],
                        $data['payment_date'],
                        $data['payment_method'],
                        $data['payment_status'],
                        $data['id']
                    ]);
                    echo json_encode(['success' => true, 'message' => 'Payment updated successfully']);
                    break;

                case 'delete':
                    $stmt = $pdo->prepare("DELETE FROM payments WHERE id = ?");
                    $stmt->execute([$data['id']]);
                    echo json_encode(['success' => true, 'message' => 'Payment deleted successfully']);
                    break;

                case 'get':
                    $stmt = $pdo->prepare("SELECT * FROM payments WHERE id = ?");
                    $stmt->execute([$data['id']]);
                    $payment = $stmt->fetch(PDO::FETCH_ASSOC);
                    if ($payment) {
                        echo json_encode(['success' => true, 'payment' => $payment]);
                    } else {
                        echo json_encode(['success' => false, 'message' => 'Payment not found']);
                    }
                    break;

                default:
                    echo json_encode(['success' => false, 'message' => 'Invalid action']);
            }
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Error: ' . $e->getMessage()]);
        }
    }
    exit;
}

$clientsQuery = $pdo->query("SELECT id, CONCAT(firstName, ' ', lastName) AS name FROM clients");
$clients = $clientsQuery->fetchAll(PDO::FETCH_ASSOC);

$paymentsQuery = $pdo->query("SELECT p.id, p.client_id, CONCAT(c.firstName, ' ', c.lastName) AS client_name, p.policy_type, p.amount, p.payment_date, p.payment_method, p.payment_status FROM payments p JOIN clients c ON p.client_id = c.id");
$payments = $paymentsQuery->fetchAll(PDO::FETCH_ASSOC);

$categories = [
    'platinum' => ['count' => 0, 'total' => 0],
    'gold' => ['count' => 0, 'total' => 0],
    'silver' => ['count' => 0, 'total' => 0],
];

foreach ($payments as $payment) {
    if ($payment['amount'] >= 190000) {
        $categories['platinum']['count']++;
        $categories['platinum']['total'] += $payment['amount'];
    } elseif ($payment['amount'] >= 50000) {
        $categories['gold']['count']++;
        $categories['gold']['total'] += $payment['amount'];
    } else {
        $categories['silver']['count']++;
        $categories['silver']['total'] += $payment['amount'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance AI | Payments</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../Css/payments.css">
</head>
<body>
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <div class="logo-container">
                <img src="../Images/Logo.png" alt="Insurance AI Logo" class="logo">
                <span class="company-name">Insurance AI</span>
            </div>
        </div>
        
        <nav class="navigation">
            <a href="../dashboard.php" class="nav-item">
                <i class="fas fa-tachometer-alt nav-icon"></i>
                <span class="nav-text">Dashboard</span>
            </a>
            <a href="clients.php" class="nav-item">
                <i class="fas fa-users nav-icon"></i>
                <span class="nav-text">Clients</span>
            </a>
            <a href="payments.php" class="nav-item active">
                <i class="fas fa-money-check-dollar nav-icon"></i>
                <span class="nav-text">Payments</span>
            </a>
            <a href="policies.php" class="nav-item">
                <i class="fas fa-book nav-icon"></i>
                <span class="nav-text">Policies</span>
            </a>
            <a href="analysis.php" class="nav-item">
                <i class="fas fa-chart-bar nav-icon"></i>
                <span class="nav-text">Analysis</span>
            </a>
            <a href="Data Search.php" class="nav-item">
                <i class="fas fa-search nav-icon"></i>
                <span class="nav-text">Data Search</span>
            </a>
            <a href="Claims.php" class="nav-item">
                <i class="fas fa-file-invoice-dollar nav-icon"></i>
                <span class="nav-text">Claims</span>
            </a>
            <a href="Report.php" class="nav-item">
                <i class="fas fa-file-alt nav-icon"></i>
                <span class="nav-text">Reports</span>
            </a>
            <a href="../index.php?logout=true" class="nav-item">
                <i class="fas fa-sign-out-alt nav-icon"></i>
                <span class="nav-text">Logout</span>
            </a>
        </nav>
        
        <div class="sidebar-footer">
            &copy; <?= date('Y') ?> Insurance AI Portal
        </div>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="page-header">
            <div class="page-title">
                <div class="icon">
                    <i class="fas fa-money-check-dollar"></i>
                </div>
                <h1>Payment Management</h1>
            </div>
            <div class="page-stats">
                <p>Total Collected: MKW<?= isset($categories) ? number_format(array_sum(array_column($categories, 'total'))) : '0' ?></p>
                <p>Active Policies: <?= isset($payments) ? count($payments) : '0' ?></p>
            </div>
        </div>
        
        <!-- Summary Boxes -->
        <div class="summary-row">
            <div class="summary-box">
                <h3>Platinum Policies</h3>
                <p>Count: <?= isset($categories['platinum']['count']) ? $categories['platinum']['count'] : '0' ?></p>
                <p>Total: MKW<?= isset($categories['platinum']['total']) ? number_format($categories['platinum']['total']) : '0' ?></p>
            </div>
            <div class="summary-box">
                <h3>Gold Policies</h3>
                <p>Count: <?= isset($categories['gold']['count']) ? $categories['gold']['count'] : '0' ?></p>
                <p>Total: MKW<?= isset($categories['gold']['total']) ? number_format($categories['gold']['total']) : '0' ?></p>
            </div>
            <div class="summary-box">
                <h3>Silver Policies</h3>
                <p>Count: <?= isset($categories['silver']['count']) ? $categories['silver']['count'] : '0' ?></p>
                <p>Total: MKW<?= isset($categories['silver']['total']) ? number_format($categories['silver']['total']) : '0' ?></p>
            </div>
        </div>
        
        <!-- Add/Edit Payment Form -->
        <div class="payment-card">
            <div class="card-header">
                <h2 id="formTitle">Record New Payment</h2>
            </div>
            
            <form id="payment-form" method="POST">
                <input type="hidden" name="id" id="payment-id">
                
                <div class="form-row">
                    <div class="form-col">
                        <div class="form-group">
                            <label for="client-name" class="form-label">Client Name</label>
                            <select id="client-name" name="client-name" required class="form-select">
                                <option value="">Select Client</option>
                                <?php if(isset($clients)): ?>
                                    <?php foreach ($clients as $client): ?>
                                        <option value="<?= $client['id'] ?>"><?= $client['name'] ?></option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-col">
                        <div class="form-group">
                            <label for="policy-type" class="form-label">Payment Category</label>
                            <select id="policy-type" name="policy-type" required class="form-select">
                                <option value="">Select Payment Category</option>
                                <option value="silver">Silver</option>
                                <option value="gold">Gold</option>
                                <option value="platinum">Platinum</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-col">
                        <div class="form-group">
                            <label for="payment-amount" class="form-label">Payment Amount</label>
                            <input type="number" id="payment-amount" name="payment-amount" required class="form-control">
                        </div>
                    </div>
                    <div class="form-col">
                        <div class="form-group">
                            <label for="payment-date" class="form-label">Payment Date</label>
                            <input type="date" id="payment-date" name="payment-date" required class="form-control">
                        </div>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-col">
                        <div class="form-group">
                            <label for="payment-method" class="form-label">Payment Method</label>
                            <select id="payment-method" name="payment-method" required class="form-select">
                                <option value="">Select Payment Method</option>
                                <option value="Tnm_Mpamba">Tnm Mpamba</option>
                                <option value="Airtel_Money">Airtel Money</option>
                                <option value="bank_transfer">Bank Transfer</option>
                                <option value="cash">Cash</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-col">
                        <div class="form-group">
                            <label for="payment-status" class="form-label">Payment Status</label>
                            <select id="payment-status" name="payment-status" required class="form-select">
                                <option value="">Select Payment Status</option>
                                <option value="Pending">Starter</option>
                                <option value="Completed">Completed</option>
                                <option value="failed">Overdue</option>
                            </select>
                        </div>
                    </div>
                </div>
                
                <div class="btn-group">
                    <button type="button" onclick="resetForm()" class="btn btn-secondary">
                        <i class="fas fa-undo"></i> Clear Form
                    </button>
                    <button type="submit" id="submit-button" class="btn btn-primary">
                        <i class="fas fa-save"></i> Save Payment
                    </button>
                </div>
            </form>
        </div>
        
        <!-- Payments List -->
        <div class="payment-card">
            <div class="card-header">
                <h2>Payment Records</h2>
            </div>
            
            <div class="search-container">
                <input type="text" class="search-input" id="search-input" placeholder="Search payments...">
            </div>
            
            <div class="table-wrapper">
                <table class="payments-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Client Name</th>
                            <th>Policy Type</th>
                            <th>Amount</th>
                            <th>Payment Date</th>
                            <th>Payment Method</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (isset($payments) && count($payments) > 0): ?>
                            <?php foreach ($payments as $payment): ?>
                                <tr>
                                    <td><?= $payment['id'] ?></td>
                                    <td><?= $payment['client_name'] ?></td>
                                    <td><span class="badge badge-info"><?= $payment['policy_type'] ?></span></td>
                                    <td>MKW<?= number_format($payment['amount']) ?></td>
                                    <td><?= date('M d, Y', strtotime($payment['payment_date'])) ?></td>
                                    <td><?= $payment['payment_method'] ?></td>
                                    <td>
                                        <?php 
                                        $statusClass = '';
                                        if ($payment['payment_status'] == 'Completed') {
                                            $statusClass = 'badge-success';
                                        } else if ($payment['payment_status'] == 'Pending') {
                                            $statusClass = 'badge-warning';
                                        } else if ($payment['payment_status'] == 'failed') {
                                            $statusClass = 'badge-danger';
                                        }
                                        ?>
                                        <span class="badge <?= $statusClass ?>"><?= $payment['payment_status'] ?></span>
                                    </td>
                                    <td class="action-buttons">
                                        <button onclick="editPayment(<?= $payment['id'] ?>)" class="btn btn-warning btn-sm">
                                            <i class="fas fa-edit"></i> Edit
                                        </button>
                                        <button onclick="deletePayment(<?= $payment['id'] ?>)" class="btn btn-danger btn-sm">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="8" style="text-align: center;">No payments found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <script>
        // Form submission handling
        document.getElementById('payment-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form values
            const formData = {
                client_id: document.getElementById('client-name').value,
                policy_type: document.getElementById('policy-type').value,
                amount: document.getElementById('payment-amount').value,
                payment_date: document.getElementById('payment-date').value,
                payment_method: document.getElementById('payment-method').value,
                payment_status: document.getElementById('payment-status').value
            };
            
            // Check if it's an update or new record
            const paymentId = document.getElementById('payment-id').value;
            let action = 'add';
            
            if (paymentId) {
                action = 'update';
                formData.id = paymentId;
            }
            
            // Add action to form data
            formData.action = action;
            
            // Send data via fetch API
            fetch(window.location.href, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    // Reload page to show updated data
                    window.location.reload();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while processing your request.');
            });
        });
        
        function editPayment(id) {
            // Fetch payment data
            fetch(window.location.href, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    action: 'get',
                    id: id
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const payment = data.payment;
                    
                    // Fill the form with payment data
                    document.getElementById('payment-id').value = payment.id;
                    document.getElementById('client-name').value = payment.client_id;
                    document.getElementById('policy-type').value = payment.policy_type;
                    document.getElementById('payment-amount').value = payment.amount;
                    document.getElementById('payment-date').value = payment.payment_date;
                    document.getElementById('payment-method').value = payment.payment_method;
                    document.getElementById('payment-status').value = payment.payment_status;
                    
                    // Update form title and button text
                    document.getElementById('formTitle').textContent = 'Edit Payment';
                    document.getElementById('submit-button').innerHTML = '<i class="fas fa-save"></i> Update Payment';
                    
                    // Scroll to form
                    document.querySelector('.payment-card').scrollIntoView({behavior: 'smooth'});
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while fetching payment data.');
            });
        }
        
        function deletePayment(id) {
            if (confirm('Are you sure you want to delete this payment?')) {
                fetch(window.location.href, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        action: 'delete',
                        id: id
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        // Reload page to update the table
                        window.location.reload();
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    alert('An error occurred while deleting the payment.');
                });
            }
        }
        
        function resetForm() {
            document.getElementById('formTitle').textContent = 'Record New Payment';
            document.getElementById('payment-form').reset();
            document.getElementById('payment-id').value = '';
            document.getElementById('submit-button').innerHTML = '<i class="fas fa-save"></i> Save Payment';
        }
        
        // Search functionality
        document.getElementById('search-input').addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const tableRows = document.querySelectorAll('.payments-table tbody tr');
            
            tableRows.forEach(row => {
                let found = false;
                row.querySelectorAll('td').forEach(cell => {
                    if (cell.textContent.toLowerCase().includes(searchTerm)) {
                        found = true;
                    }
                });
                
                row.style.display = found ? '' : 'none';
            });
        });
        
        // Set default date to today
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date();
            const formattedDate = today.toISOString().substr(0, 10);
            document.getElementById('payment-date').value = formattedDate;
        });
    </script>
</body>
</html>