<?php
// Database Connection
$host = 'localhost';
$dbname = 'insurance_ai';
$username = 'root';
$password = '';

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch Clients for the Dropdown
$clients = $conn->query("SELECT id, CONCAT(firstName, ' ', lastName) AS name FROM clients");

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action === 'add_policy') {
        $clientId = intval($_POST['client_id']);
        $policyType = trim($_POST['policy_type']);
        $coverageAmount = floatval($_POST['coverage_amount']);
        $premium = trim($_POST['premium']);
        $startDate = trim($_POST['start_date']);
        $endDate = trim($_POST['end_date']);

       // Generate sequential Policy Number (PN0001, PN0002, etc.)
            $stmt = $conn->prepare("SELECT policy_number FROM policies WHERE policy_number LIKE 'PN%' ORDER BY id DESC LIMIT 1");
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $lastPolicyNumber = $row['policy_number'];
                $numericPart = intval(substr($lastPolicyNumber, 2)); // Extract number after 'PN'
                $newNumericPart = $numericPart + 1;
            } else {
                // No existing policies, start with 1
                $newNumericPart = 1;
            }

            // Format with leading zeros (PN0001 format)
            $policyNumber = 'PN' . str_pad($newNumericPart, 4, '0', STR_PAD_LEFT);

            $stmt->close();

            // Continue with your existing insertion code
            $stmt = $conn->prepare("INSERT INTO policies (client_name, policy_type, policy_number, coverage_amount, premium, start_date, end_date) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param('issdsss', $clientId, $policyType, $policyNumber, $coverageAmount, $premium, $startDate, $endDate);

            if ($stmt->execute()) {
                echo "<script>alert('Policy added successfully. Policy Number: $policyNumber');</script>";
            } else {
                echo "<script>alert('Error adding policy: " . $stmt->error . "');</script>";
            }
            $stmt->close();
            }
}

// Fetch Policies
$policies = $conn->query("SELECT p.*, CONCAT(c.firstName, ' ', c.lastName) AS client_name FROM policies p INNER JOIN clients c ON p.client_name = c.id ORDER BY p.id DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance | Policies</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../Css/payments.css">
</head>
<body>
    <div class="d-flex">
        <!-- Blue Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <div class="d-flex align-items-center justify-content-center">
                    <img src="../Images/Logo.png" alt="Company Logo" class="me-2" style="width: 40px;">
                    <span class="company-name fs-5 fw-bold">Insurance AI</span>
                </div>
            </div>
            
            <nav class="navigation mt-3">
                <a href="../dashboard.php" class="nav-item">
                    <i class="fas fa-tachometer-alt nav-icon"></i>
                    <span>Dashboard</span>
                </a>
                <a href="clients.php" class="nav-item">
                    <i class="fas fa-users nav-icon"></i>
                    <span>Clients</span>
                </a>
                <a href="payments.php" class="nav-item">
                    <i class="fas fa-money-check-dollar nav-icon"></i>
                    <span>Payments</span>
                </a>
                <a href="policies.php" class="nav-item active">
                    <i class="fas fa-book nav-icon"></i>
                    <span>Policies</span>
                </a>
                <a href="analysis.php" class="nav-item">
                    <i class="fas fa-chart-bar nav-icon"></i>
                    <span>Analysis</span>
                </a>
                <a href="Data Search.php" class="nav-item">
                    <i class="fas fa-search nav-icon"></i>
                    <span>Data Search</span>
                </a>
                <a href="Claims.php" class="nav-item">
                    <i class="fas fa-file-invoice-dollar nav-icon"></i>
                    <span>Claims</span>
                </a>
                <a href="Report.php" class="nav-item">
                    <i class="fas fa-file-alt nav-icon"></i>
                    <span>Reports</span>
                </a>
                <a href="../index.php?logout=true" class="nav-item">
                    <i class="fas fa-sign-out-alt nav-icon"></i>
                    <span>Logout</span>
                </a>
            </nav>
            
            <div class="sidebar-footer">
                &copy; <?= date('Y') ?> Insurance AI Portal
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Page Header with Dark Blue Title -->
            <div class="page-header">
                <div class="d-flex align-items-center">
                    <div class="icon bg-darkblue text-white rounded-circle d-flex align-items-center justify-content-center me-4" style="width: 60px; height: 60px;">
                        <i class="fas fa-book fs-4"></i>
                    </div>
                    <h1 class="page-title">Policies Management</h1> <!-- Dark blue title -->
                </div>
            </div>

            <!-- Policy Form Card -->
            <div class="card mb-4">
                <div class="card-header">
                    <h2 class="m-0" id="formTitle">Add New Policy</h2>
                </div>
                <div class="card-body">
                    <form id="policy-form" method="POST" action="">
                        <input type="hidden" name="action" id="form-action" value="add_policy">
                        <input type="hidden" name="policy_id" id="policy-id">
                        <input type="hidden" id="policy-number" name="policy_number">
                        
                        <div class="row g-4">
                            <!-- Client Selection -->
                            <div class="col-md-6">
                                <label for="client-id" class="form-label">Client Name</label>
                                <select id="client-id" name="client_id" class="form-select" required>
                                    <option value="">Select a client</option>
                                    <?php while ($client = $clients->fetch_assoc()): ?>
                                        <option value="<?= $client['id']; ?>"><?= htmlspecialchars($client['name']); ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            
                            <!-- Policy Type -->
                            <div class="col-md-6">
                                <label for="policy-type" class="form-label">Policy Type</label>
                                <select id="policy-type" name="policy_type" class="form-select" required>
                                    <option value="">Select policy type</option>
                                    <option value="health">Health</option>
                                    <option value="life">Life</option>
                                    <option value="auto">Auto</option>
                                    <option value="home">Home</option>
                                </select>
                            </div>
                            
                            <!-- Coverage Amount -->
                            <div class="col-md-6">
                                <label for="coverage-amount" class="form-label">Coverage Amount</label>
                                <input type="number" id="coverage-amount" name="coverage_amount" class="form-control" required>
                            </div>
                            
                            <!-- Premium -->
                            <div class="col-md-6">
                                <label for="premium" class="form-label">Premium</label>
                                <input type="text" id="premium" name="premium" class="form-control" required>
                            </div>
                            
                            <!-- Start Date -->
                            <div class="col-md-6">
                                <label for="start-date" class="form-label">Start Date</label>
                                <input type="date" id="start-date" name="start_date" class="form-control" required>
                            </div>
                            
                            <!-- End Date -->
                            <div class="col-md-6">
                                <label for="end-date" class="form-label">End Date</label>
                                <input type="date" id="end-date" name="end_date" class="form-control" required>
                            </div>
                            
                            <!-- Form Buttons -->
                            <div class="col-12 d-flex justify-content-between mt-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i>Save Policy
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Policies Table Card -->
            <div class="card">
                <div class="card-header">
                    <h2 class="m-0">Policy Records</h2>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Policy Type</th>
                                    <th>Policy Number</th>
                                    <th>Coverage Amount</th>
                                    <th>Premium</th>
                                    <th>Start Date</th>
                                    <th>End Date</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $policies->fetch_assoc()): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($row['client_name']) ?></td>
                                        <td>
                                            <?php 
                                            $badgeClass = '';
                                            switch($row['policy_type']) {
                                                case 'health': $badgeClass = 'badge-health'; break;
                                                case 'life': $badgeClass = 'badge-life'; break;
                                                case 'auto': $badgeClass = 'badge-auto'; break;
                                                case 'home': $badgeClass = 'badge-home'; break;
                                            }
                                            ?>
                                            <span class="badge <?= $badgeClass ?>"><?= ucfirst($row['policy_type']) ?></span>
                                        </td>
                                        <td><?= htmlspecialchars($row['policy_number']) ?></td>
                                        <td><?= number_format($row['coverage_amount']) ?></td>
                                        <td><?= htmlspecialchars($row['premium']) ?></td>
                                        <td><?= date('M d, Y', strtotime($row['start_date'])) ?></td>
                                        <td><?= date('M d, Y', strtotime($row['end_date'])) ?></td>
                                        <td>
                                            <button 
                                                onclick="editPolicy(
                                                    '<?= $row['id'] ?>',
                                                    
                                                    '<?= $row['policy_type'] ?>',
                                                    '<?= $row['policy_number'] ?>',
                                                    '<?= $row['coverage_amount'] ?>',
                                                    '<?= $row['premium'] ?>',
                                                    '<?= $row['start_date'] ?>',
                                                    '<?= $row['end_date'] ?>'
                                                )" 
                                                class="btn btn-sm btn-primary me-2">
                                                <i class="fas fa-edit me-1"></i>Edit
                                            </button>
                                            
                                            <form method="POST" action="" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this policy?');">
                                                <input type="hidden" name="action" value="delete_policy">
                                                <input type="hidden" name="policy_id" value="<?= $row['id'] ?>">
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="fas fa-trash me-1"></i>Delete
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        function editPolicy(id, clientId, policyType, policyNumber, coverageAmount, premium, startDate, endDate) {
            document.getElementById('form-action').value = 'update_policy';
            document.getElementById('policy-id').value = id;
            document.getElementById('client-id').value = clientId;
            document.getElementById('policy-type').value = policyType;
            document.getElementById('policy-number').value = policyNumber;
            document.getElementById('coverage-amount').value = coverageAmount;
            document.getElementById('premium').value = premium;
            document.getElementById('start-date').value = startDate;
            document.getElementById('end-date').value = endDate;
            
            document.getElementById('formTitle').textContent = 'Edit Policy';
            document.querySelector('html, body').scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        }
    </script>
</body>
</html>