<?php
session_start(); // Start session first

// Handle logout
if (isset($_GET['logout'])) {
    // Unset all session variables
    $_SESSION = array();

    // Destroy the session
    session_destroy();

    // Redirect to login page
    header("Location: index.php");
    exit();
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "daily_planner";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$taskAdded = false;
$taskDeleted = false;

// Add new task
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_task'])) {
    $time = $conn->real_escape_string($_POST['time']);
    $task = $conn->real_escape_string($_POST['task']);
    $section = $conn->real_escape_string($_POST['section']);

    $sql = "INSERT INTO tasks (time, task, section, completed) VALUES ('$time', '$task', '$section', 0)";

    if ($conn->query($sql)) {
        $taskAdded = true;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Delete task
if (isset($_GET['delete_id'])) {
    $id = intval($_GET['delete_id']);
    $sql = "DELETE FROM tasks WHERE id=$id";

    if ($conn->query($sql)) {
        $taskDeleted = true;
        header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
        exit();
    } else {
        echo "Error deleting task: " . $conn->error;
    }
}

// Toggle task completion
if (isset($_GET['toggle_id'])) {
    $id = intval($_GET['toggle_id']);
    $sql = "UPDATE tasks SET completed = NOT completed WHERE id=$id";

    if ($conn->query($sql)) {
        header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
        exit();
    } else {
        echo "Error updating task: " . $conn->error;
    }
}

// Function to retrieve tasks by section
function getTasks($conn, $section = null) {
    $sql = "SELECT * FROM tasks";
    if ($section) {
        $safe_section = $conn->real_escape_string($section);
        $sql .= " WHERE section='$safe_section'";
    }
    $sql .= " ORDER BY time ASC";

    $result = $conn->query($sql);
    $tasks = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $tasks[] = $row;
        }
    }

    return $tasks;
}

// Count tasks per section
$morningCount = count(getTasks($conn, 'morning'));
$afternoonCount = count(getTasks($conn, 'afternoon'));
$eveningCount = count(getTasks($conn, 'evening'));

// Fetch user data (example for user with id = 1)
$userId = 1;
$userData = [];
$userSql = "SELECT * FROM users WHERE id = $userId";
$userResult = $conn->query($userSql);
if ($userResult->num_rows > 0) {
    $userData = $userResult->fetch_assoc();
}
?>

<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daily Planner|Web-Application</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="Assets/CSS/style.css">
</head>
<body>
    
    <div class="header">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center">
                  <h1>
                    <a href="index.php" style="text-decoration: none; color: inherit;">
                      <img src="Assets/img/logo-web.png" alt="Daily Planner Logo" style="height: 70px; vertical-align: middle; margin-right: 10px;">
                      Daily Planner
                    </a>
                  </h1>
                  <div class="dropdown">
                    <img src="Assets/img/avatar.png" 
                         alt="User Avatar" 
                         class="avatar dropdown-toggle" 
                         id="userDropdown" 
                         data-bs-toggle="dropdown" 
                         aria-expanded="false">
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                      <li><a class="dropdown-item" href="#" id="viewProfileBtn"><i class="fas fa-user me-2"></i>View Profile</a></li>
                      <li><hr class="dropdown-divider"></li>
                      <li><a class="dropdown-item" href="?logout=true"><i class="fas fa-sign-out-alt me-2"></i> Logout</a></li>
                    </ul>
                  </div>
            </div>
            <nav class="mt-3">
                <ul class="nav nav-pills">
                    <li class="nav-item">
                        <a class="nav-link active text-white" href="#" data-target="dashboard"><i class="fas fa-home me-1"></i>Dashboard</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link text-white" href="#" data-target="tasks"><i class="fas fa-tasks me-1"></i>Tasks</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
     
<div id="profilePanel" class="profile-panel">
    <div class="profile-header">
      <button id="closeProfileBtn" class="btn-close btn-close-white"></button>
      <h3><i class="fas fa-user-circle me-2"></i> User Profile</h3>
    </div>
    <div class="profile-content">
      <div class="profile-avatar-container">
        <img src="Assets/img/avatar.png" 
             alt="User Avatar" 
             class="profile-avatar">
      </div>
      
      <div class="profile-details">
        <div class="profile-field">
          <label><i class="fas fa-user me-2"></i>Name:</label>
          <span id="profileName"><?php echo isset($userData['name']) ? htmlspecialchars($userData['name']) : 'Chris Anavie'; ?></span>
        </div>
        <div class="profile-field">
          <label><i class="fas fa-envelope me-2"></i>Email:</label>
          <span id="profileEmail"><?php echo isset($userData['email']) ? htmlspecialchars($userData['email']) : 'chrisanavie@gmail.com'; ?></span>
        </div>
        <div class="profile-field">
          <label><i class="fas fa-phone me-2"></i>Phone:</label>
          <span id="profilePhone"><?php echo isset($userData['phone']) ? htmlspecialchars($userData['phone']) : '+265 996 61 50 00'; ?></span>
        </div>
        <div class="profile-field">
          <label><i class="fas fa-briefcase me-2"></i>Position:</label>
          <span id="profilePosition"><?php echo isset($userData['position']) ? htmlspecialchars($userData['position']) : 'Web Developer'; ?></span>
        </div>
      </div>
    </div>
  </div>
    <div class="container">
        <?php if ($taskAdded): ?>
            <div class="alert alert-success alert-dismissible fade show mt-3" role="alert">
                Task added successfully!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        <?php if ($taskDeleted): ?>
            <div class="alert alert-danger alert-dismissible fade show mt-3" role="alert">
                Task deleted successfully!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
        
        
        <div class="digital-clock" id="clock">00:00:00</div>

        
        <div class="scene">
            <div class="sky"></div>
            <div class="sun" id="sun"></div>
            <div class="ground"></div>
        </div>

        <div id="content-area">
            
            <div id="dashboard" class="active">
                <div class="row">
                   
                    <div class="col-md-4">
                        <div class="stat-card">
                            <div class="card-header">
                                <i class="fas fa-coffee me-2"></i>Morning
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><span id="morning-count"><?php echo $morningCount; ?></span> Tasks</h5>
                                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                    <input type="hidden" name="section" value="morning">
                                    <div class="input-group mb-3">
                                        <input type="time" class="form-control" name="time" id="morning-time" min="06:00" max="11:59" required>
                                        <input type="text" class="form-control" name="task" id="morning-task" placeholder="Add a morning task" required>
                                        <button type="submit" name="add_task" class="btn btn-add">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </form>
                                <div id="morning-tasks" class="tasks-container">
                                    <?php foreach (getTasks($conn, 'morning') as $task): ?>
                                        <div class="task-item <?php echo $task['completed'] ? 'completed' : ''; ?>">
                                            <span>
                                                <?php echo date("H:i", strtotime($task['time'])); ?> - <?php echo htmlspecialchars($task['task']); ?>
                                            </span>
                                            <div class="task-actions">
                                                <a href="?toggle_id=<?php echo $task['id']; ?>" class="btn btn-sm <?php echo $task['completed'] ? 'btn-warning' : 'btn-success'; ?>">
                                                    <i class="fas <?php echo $task['completed'] ? 'fa-undo' : 'fa-check'; ?>"></i>
                                                </a>
                                                <a href="?delete_id=<?php echo $task['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this task?');">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                   
                    <div class="col-md-4">
                        <div class="stat-card">
                            <div class="card-header">
                                <i class="fas fa-sun me-2"></i>Afternoon
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><span id="afternoon-count"><?php echo $afternoonCount; ?></span> Tasks</h5>
                                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                    <input type="hidden" name="section" value="afternoon">
                                    <div class="input-group mb-3">
                                        <input type="time" class="form-control" name="time" id="afternoon-time" min="12:00" max="17:59" required>
                                        <input type="text" class="form-control" name="task" id="afternoon-task" placeholder="Add an afternoon task" required>
                                        <button type="submit" name="add_task" class="btn btn-add">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </form>
                                <div id="afternoon-tasks" class="tasks-container">
                                    <?php foreach (getTasks($conn, 'afternoon') as $task): ?>
                                        <div class="task-item <?php echo $task['completed'] ? 'completed' : ''; ?>">
                                            <span>
                                                <?php echo date("H:i", strtotime($task['time'])); ?> - <?php echo htmlspecialchars($task['task']); ?>
                                            </span>
                                            <div class="task-actions">
                                                <a href="?toggle_id=<?php echo $task['id']; ?>" class="btn btn-sm <?php echo $task['completed'] ? 'btn-warning' : 'btn-success'; ?>">
                                                    <i class="fas <?php echo $task['completed'] ? 'fa-undo' : 'fa-check'; ?>"></i>
                                                </a>
                                                <a href="?delete_id=<?php echo $task['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this task?');">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="col-md-4">
                        <div class="stat-card">
                            <div class="card-header">
                                <i class="fas fa-moon me-2"></i>Evening
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><span id="evening-count"><?php echo $eveningCount; ?></span> Tasks</h5>
                                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                    <input type="hidden" name="section" value="evening">
                                    <div class="input-group mb-3">
                                        <input type="time" class="form-control" name="time" id="evening-time" min="18:00" max="23:59" required>
                                        <input type="text" class="form-control" name="task" id="evening-task" placeholder="Add an evening task" required>
                                        <button type="submit" name="add_task" class="btn btn-add">
                                            <i class="fas fa-plus"></i>
                                        </button>
                                    </div>
                                </form>
                                <div id="evening-tasks" class="tasks-container">
                                    <?php foreach (getTasks($conn, 'evening') as $task): ?>
                                        <div class="task-item <?php echo $task['completed'] ? 'completed' : ''; ?>">
                                            <span>
                                                <?php echo date("H:i", strtotime($task['time'])); ?> - <?php echo htmlspecialchars($task['task']); ?>
                                            </span>
                                            <div class="task-actions">
                                                <a href="?toggle_id=<?php echo $task['id']; ?>" class="btn btn-sm <?php echo $task['completed'] ? 'btn-warning' : 'btn-success'; ?>">
                                                    <i class="fas <?php echo $task['completed'] ? 'fa-undo' : 'fa-check'; ?>"></i>
                                                </a>
                                                <a href="?delete_id=<?php echo $task['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this task?');">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div id="tasks">
                <div class="row mb-4">
                    <div class="col">
                        <h3>All Tasks</h3>
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Task</th>
                                        <th>Section</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody id="tasks-table-body">
                                    <?php foreach (getTasks($conn) as $task): ?>
                                        <tr class="<?php echo $task['completed'] ? 'table-secondary' : ''; ?>">
                                            <td><?php echo date("H:i", strtotime($task['time'])); ?></td>
                                            <td><?php echo htmlspecialchars($task['task']); ?></td>
                                            <td><?php echo ucfirst($task['section']); ?></td>
                                            <td><?php echo $task['completed'] ? 'Completed' : 'Pending'; ?></td>
                                            <td>
                                                <a href="?toggle_id=<?php echo $task['id']; ?>" class="btn btn-sm <?php echo $task['completed'] ? 'btn-warning' : 'btn-success'; ?>">
                                                    <i class="fas <?php echo $task['completed'] ? 'fa-undo' : 'fa-check'; ?>"></i>
                                                </a>
                                                <a href="?delete_id=<?php echo $task['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this task?');">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
       
        function updateClock() {
            const now = new Date();
            const hours = now.getHours().toString().padStart(2, '0');
            const minutes = now.getMinutes().toString().padStart(2, '0');
            const seconds = now.getSeconds().toString().padStart(2, '0');
            document.getElementById('clock').textContent = `${hours}:${minutes}:${seconds}`;
            
            
            const sun = document.getElementById('sun');
            const hour = now.getHours();
            const percent = hour / 24;
            const sceneWidth = document.querySelector('.scene').offsetWidth;
            const sunWidth = 50;
            const left = (sceneWidth - sunWidth) * percent;
            
            
            const heightPercent = Math.sin(percent * Math.PI);
            const sceneHeight = document.querySelector('.scene').offsetHeight;
            const skyHeight = sceneHeight * 0.7;
            const sunHeight = skyHeight * heightPercent - 25; 
            
            sun.style.left = `${left}px`;
            sun.style.bottom = `${sunHeight}px`;
        }
        
        setInterval(updateClock, 1000);
        updateClock();
        
       
        document.querySelectorAll('[data-target]').forEach(tab => {
            tab.addEventListener('click', function(e) {
                e.preventDefault();
                
                
                document.querySelectorAll('.nav-link').forEach(link => {
                    link.classList.remove('active');
                });
                this.classList.add('active');
                
                
                const target = this.getAttribute('data-target');
                document.querySelectorAll('#content-area > div').forEach(content => {
                    content.classList.remove('active');
                });
                document.getElementById(target).classList.add('active');
            });
        });
        
        
        document.getElementById('viewProfileBtn').addEventListener('click', function(e) {
            e.preventDefault();
            document.getElementById('profilePanel').classList.add('show');
        });
        
        document.getElementById('closeProfileBtn').addEventListener('click', function() {
            document.getElementById('profilePanel').classList.remove('show');
        });
    </script>
</body>
</html>
<?php

$conn->close();
?>