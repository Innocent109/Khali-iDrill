<?php
session_start();

// Database configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'daily_planner');
define('DB_USER', 'root');
define('DB_PASS', '');

// Initialize variables
$errors = [];
$success = '';
$current_page = isset($_GET['page']) ? htmlspecialchars($_GET['page']) : 'login';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Create database connection
        $pdo = new PDO(
            "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        );

        // Login form submission
        if (isset($_POST['login_email'])) {
            $email = filter_input(INPUT_POST, 'login_email', FILTER_SANITIZE_EMAIL);
            $password = $_POST['login_password'];

            if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors['login'] = "Please enter a valid email address";
            } else {
                $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
                $stmt->execute([$email]);
                $user = $stmt->fetch();

                if ($user && password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = htmlspecialchars($user['name']);
                    $_SESSION['user_email'] = htmlspecialchars($user['email']);
                    $_SESSION['logged_in'] = true;
                    
                    $success = "Login successful! Redirecting...";
                    header("Refresh: 2; url=Dashboard.php");
                    exit();
                } else {
                    $errors['login'] = "Invalid email or password";
                }
            }
            $current_page = 'login';
        }

        // Registration form submission
        elseif (isset($_POST['register_name'])) {
            $name = trim(filter_input(INPUT_POST, 'register_name', FILTER_SANITIZE_STRING));
            $email = filter_input(INPUT_POST, 'register_email', FILTER_SANITIZE_EMAIL);
            $password = $_POST['register_password'];
            $confirm_password = $_POST['register_confirm'];

            // Validation
            if (empty($name)) $errors['name'] = "Name is required";
            if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors['email'] = "Valid email is required";
            if (strlen($password) < 8) $errors['password'] = "Password must be at least 8 characters";
            if ($password !== $confirm_password) $errors['confirm'] = "Passwords don't match";

            // Check if email exists
            if (empty($errors['email'])) {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                $stmt->execute([$email]);
                if ($stmt->fetch()) $errors['email'] = "Email already registered";
            }

            if (empty($errors)) {
                $hashed_password = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
                $stmt->execute([$name, $email, $hashed_password]);
                
                $success = "Registration successful! You can now login.";
                $current_page = 'login';
            } else {
                $current_page = 'register';
            }
        }

        // Password recovery form submission
        elseif (isset($_POST['recover_email'])) {
            $email = filter_input(INPUT_POST, 'recover_email', FILTER_SANITIZE_EMAIL);

            if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $errors['recover'] = "Please enter a valid email address";
            } else {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
                $stmt->execute([$email]);
                if ($stmt->fetch()) {
                    $_SESSION['reset_email'] = $email;
                    $_SESSION['reset_token'] = bin2hex(random_bytes(32));
                    $current_page = 'reset';
                } else {
                    $errors['recover'] = "Email not found in our system";
                }
            }
            $current_page = empty($errors) ? 'reset' : 'recover';
        }

        // Password reset form submission
        elseif (isset($_POST['new_password'])) {
            if (!isset($_SESSION['reset_email']) || !isset($_SESSION['reset_token'])) {
                $errors['reset'] = "Invalid password reset request";
                $current_page = 'recover';
            } else {
                $new_password = $_POST['new_password'];
                $confirm_password = $_POST['confirm_password'];
                $email = $_SESSION['reset_email'];

                if (strlen($new_password) < 8) {
                    $errors['reset'] = "Password must be at least 8 characters";
                } elseif ($new_password !== $confirm_password) {
                    $errors['reset'] = "Passwords do not match";
                }

                if (empty($errors)) {
                    $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
                    $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE email = ?");
                    $stmt->execute([$hashed_password, $email]);

                    unset($_SESSION['reset_email']);
                    unset($_SESSION['reset_token']);
                    $success = "Password reset successfully! You can now login with your new password.";
                    $current_page = 'login';
                } else {
                    $current_page = 'reset';
                }
            }
        }

    } catch (PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        $errors['db'] = "A database error occurred. Please try again later.";
    }
}

// Check if user is already logged in
if (isset($_SESSION['logged_in']) && !isset($_GET['logout'])) {
    header("Location: Dashboard.php");
    exit();
}

// Handle logout
if (isset($_GET['logout'])) {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Daily Planner | Authentication</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="Assets/CSS/login.css">
</head>
<body>
  <div class="form-container">
    <div class="avatar">
      <div class="avatar-icon">
        <img src="Assets/img/avatar.png" alt="Avatar" />
      </div>
    </div>
    
    <!-- Login Page -->
    <div class="page <?php echo $current_page === 'login' ? 'active' : ''; ?>" id="login-page">
      <h1>Welcome</h1>
      <?php if (!empty($errors['login'])): ?>
        <div class="error-message"><?php echo htmlspecialchars($errors['login']); ?></div>
      <?php endif; ?>
      <?php if (!empty($success) && $current_page === 'login'): ?>
        <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
      <?php endif; ?>
      <form method="POST" action="?page=login">
        <div class="input-group">
          <label for="login-email">Email Address</label>
          <input type="email" id="login-email" name="login_email" placeholder="Enter your email" required>
        </div>
        <div class="input-group">
          <label for="login-password">Password</label>
          <input type="password" id="login-password" name="login_password" placeholder="Enter your password" required>
          <span class="password-toggle">👁️</span>
        </div>
        <button type="submit">Sign In</button>
      </form>
      
      <div class="divider">or continue with</div>
      
      <div class="social-login">
        <button class="social-btn">G</button>
        <button class="social-btn">f</button>
        <button class="social-btn">in</button>
      </div>
      
      <div class="form-footer">
        Don't have an account? <a href="?page=register">Sign up</a><br>
        <a href="?page=recover">Forgot password?</a>
      </div>
    </div>
    
    <!-- Registration Page -->
    <div class="page <?php echo $current_page === 'register' ? 'active' : ''; ?>" id="register-page">
      <h1>Create Account</h1>
      <?php if (!empty($errors['db'])): ?>
        <div class="error-message"><?php echo htmlspecialchars($errors['db']); ?></div>
      <?php endif; ?>
      <?php if (!empty($success) && $current_page === 'register'): ?>
        <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
      <?php endif; ?>
      
      <form method="POST" action="?page=register">
        <div class="input-group">
          <label for="register-name">Full Name</label>
          <input type="text" id="register-name" name="register_name" placeholder="Enter your full name" required>
          <?php if (!empty($errors['name'])): ?>
            <div class="error-message"><?php echo htmlspecialchars($errors['name']); ?></div>
          <?php endif; ?>
        </div>
        <div class="input-group">
          <label for="register-email">Email Address</label>
          <input type="email" id="register-email" name="register_email" placeholder="Enter your email" required>
          <?php if (!empty($errors['email'])): ?>
            <div class="error-message"><?php echo htmlspecialchars($errors['email']); ?></div>
          <?php endif; ?>
        </div>
        <div class="input-group">
          <label for="register-password">Create Password</label>
          <input type="password" id="register-password" name="register_password" placeholder="Create a password" required>
          <span class="password-toggle">👁️</span>
          <?php if (!empty($errors['password'])): ?>
            <div class="error-message"><?php echo htmlspecialchars($errors['password']); ?></div>
          <?php endif; ?>
        </div>
        <div class="input-group">
          <label for="register-confirm">Confirm Password</label>
          <input type="password" id="register-confirm" name="register_confirm" placeholder="Confirm your password" required>
          <span class="password-toggle">👁️</span>
          <?php if (!empty($errors['confirm'])): ?>
            <div class="error-message"><?php echo htmlspecialchars($errors['confirm']); ?></div>
          <?php endif; ?>
        </div>
        <button type="submit">Sign Up</button>
      </form>
      
      <div class="divider">or sign up with</div>
      
      <div class="social-login">
        <button class="social-btn">G</button>
        <button class="social-btn">f</button>
        <button class="social-btn">in</button>
      </div>
      
      <div class="form-footer">
        Already have an account? <a href="?page=login">Sign in</a>
      </div>
    </div>
    
    <!-- Password Recovery Page -->
    <div class="page <?php echo $current_page === 'recover' ? 'active' : ''; ?>" id="recover-page">
      <h1>Reset Password</h1>
      <p style="text-align: center; margin-bottom: 25px; color: var(--text-light);">
        Enter your email address and we'll help you reset your password.
      </p>
      <?php if (!empty($errors['recover'])): ?>
        <div class="error-message"><?php echo htmlspecialchars($errors['recover']); ?></div>
      <?php endif; ?>
      
      <form method="POST" action="?page=recover">
        <div class="input-group">
          <label for="recover-email">Email Address</label>
          <input type="email" id="recover-email" name="recover_email" placeholder="Enter your email" required>
        </div>
        <button type="submit">Continue</button>
      </form>
      
      <div class="form-footer">
        Remember your password? <a href="?page=login">Sign in</a>
      </div>
    </div>

    <!-- Password Reset Page -->
    <div class="page <?php echo $current_page === 'reset' ? 'active' : ''; ?>" id="reset-page">
      <h1>Set New Password</h1>
      <p style="text-align: center; margin-bottom: 25px; color: var(--text-light);">
        Please enter your new password.
      </p>
      <?php if (!empty($errors['reset'])): ?>
        <div class="error-message"><?php echo htmlspecialchars($errors['reset']); ?></div>
      <?php endif; ?>
      <?php if (!empty($success) && $current_page === 'reset'): ?>
        <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
      <?php endif; ?>
      
      <form method="POST" action="?page=reset">
        <div class="input-group">
          <label for="new-password">New Password</label>
          <input type="password" id="new-password" name="new_password" placeholder="Enter new password" required>
        </div>
        <div class="input-group">
          <label for="confirm-password">Confirm Password</label>
          <input type="password" id="confirm-password" name="confirm_password" placeholder="Confirm new password" required>
          <span class="password-toggle">👁️</span>
        </div>
        <button type="submit">Reset Password</button>
      </form>
    </div>
  </div>
  <script>
      // Toggle password visibility
  document.querySelectorAll('.password-toggle').forEach(toggle => {
    toggle.addEventListener('click', function() {
      const input = this.previousElementSibling;
      if (input.type === 'password') {
        input.type = 'text';
        this.textContent = '👁️';
      } else {
        input.type = 'password';
        this.textContent = '👁️';
      }
    });
  });

  // Auto-hide success messages after 5 seconds
  setTimeout(() => {
    const successMessages = document.querySelectorAll('.success-message');
    successMessages.forEach(msg => {
      msg.style.display = 'none';
    });
  }, 5000);
  </script>
</body>
</html>
